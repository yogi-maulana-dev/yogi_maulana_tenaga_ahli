<?php $__env->startSection('lokasi'); ?>

    <style>
        /* Blink animation */
        @keyframes blink {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        .blink {
            animation: blink 1s infinite;
        }
    </style>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4"><?php echo e(Auth::guard('superadmin')->user()->namalengkap); ?></h4>
                                    <span> - Web Developer</span>
                                </div>
                            </div>
                            <ul class="d-flex nav nav-pills mb-0 text-center profile-tab" data-toggle="slider-tab"
                                id="profile-pills-tab" role="tablist">
                                
                                <li class="nav-item">
                                    <a class="nav-link active show" data-bs-toggle="tab" href="#profile-activity"
                                        role="tab" aria-selected="false">DATA LOKASI KKN</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#profile-profile" role="tab"
                                        aria-selected="false">TAMBAH DATA LOKASI KKN</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title"><?php echo e($judul); ?></h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-4">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success mt-4">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="table-responsive">
                                    <table id="example" class="stripe hover"
                                        style="width:100%; padding-top: 1em;  padding-bottom: 1em;">
                                        <thead>
                                            <tr>
                                                <th>NIP</th>
                                                <th>Nama Lengkap</th>
                                                <th>Jenis Kelamin</th>
                                                <th>Nomor Handphone</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $alllokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($lokasi->nip); ?></td>
                                                    <td><?php echo e($lokasi->nama); ?></td>
                                                    <td><?php echo e($lokasi->jenis_kelamin); ?></td>
                                                    <td><?php echo e($lokasi->nohp); ?></td>

                                                    <td>
                                                        <!-- Tombol untuk membuka modal -->
                                                        <button type="button" class="btn btn-success"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#viewlokasiModal<?php echo e($lokasi->id); ?>">
                                                            Lihat Detail
                                                        </button>
                                                        <button type="button" class="btn btn-primary"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#editlokasiModal<?php echo e($lokasi->id); ?>">
                                                            Edit
                                                        </button>
                                                        <form
                                                            action="<?php echo e(route('superadmin.lokasi.delete', ['id' => $lokasi->id])); ?>"
                                                            method="POST" style="display: inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger"
                                                                onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                                                        </form>


                                                    </td>
                                                </tr>

                                                <!-- Modal Edit lokasi -->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>

                                            <tr>
                                                <th>NIP</th>
                                                <th>Nama Lengkap</th>
                                                <th>Jenis Kelamin</th>
                                                <th>Nomor Handphone</th>
                                                <th>Aksi</th>
                                            </tr>

                                        </tfoot>
                                    </table>
                                </div>
                            </div>

                            <!-- Modal Edit Mahasiswa -->

                        </div>

                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua kelompok akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="mb-3">


                                <form method="POST" class="row" action="<?php echo e(route('superadmin.simpan.lokasi')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-sm-6">
                                        <!--pisah-->

                                        <div class="form-group">
                                            <label class="form-label" for="provinsi">Provinsi</label>
                                            <select name="provinsi"
                                                class="form-select border-success <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                data-trigger id="provinsi">
                                                <option value="">Pilih Provinsi</option>
                                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provinsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($provinsi->id); ?>"><?php echo e($provinsi->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="kota">Kota/Kabupaten</label>
                                            <select name="kota"
                                                class="form-select border-success <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                data-trigger id="kota">
                                                <option value="">Pilih Kota/Kabupaten</option>
                                            </select>
                                            <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="kecamatan">Kecamatan</label>
                                            <select name="kecamatan"
                                                class="form-select border-success <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                data-trigger id="kecamatan">
                                                <option value="">Pilih Kecamatan</option>
                                            </select>
                                            <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="desa">Desa</label>
                                            <select name="desa"
                                                class="form-select border-success <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                data-trigger id="desa">
                                                <option value="">Pilih Desa</option>
                                            </select>
                                            <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="alamat">Alamat KKN:</label>
                                            <textarea type="number" name="alamat" class="form-control border-success <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="alamat" value="<?php echo e(old('alamat')); ?>"></textarea>
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="form-label" for="nohp">Nomor Induk Pegawai:</label>
                                            <input type="number" name="nip"
                                                class="form-control border-success <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="nip" value="<?php echo e(old('nip')); ?>">
                                            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="nama">Nama Lengkap:</label>
                                            <input type="text" name="nama"
                                                class="form-control border-success <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="nama" value="<?php echo e(old('nama')); ?>">
                                            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="nohp">Nomor Handphone:</label>
                                            <input type="number" name="nohp"
                                                class="form-control border-success <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="nohp" value="<?php echo e(old('nohp')); ?>">
                                            <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                        <label class="form-label" for="nohp">Jenis Kelamin:</label>
                                        <div class="form-group">

                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="jenis_kelamin"
                                                    id="laki_laki" value="laki_laki">
                                                <label class="form-check-label" for="laki_laki">
                                                    Laki-laki
                                                </label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="jenis_kelamin"
                                                    id="perempuan" value="perempuan">
                                                <label class="form-check-label" for="perempuan">
                                                    Perempuan
                                                </label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="desa">Agama</label>
                                            <select name="agama"
                                                class="form-select border-success <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                data-trigger id="agama">
                                                <option value="">Pilih Agama</option>
                                                <option value="Islam">Islam</option>
                                                <option value="Kristen">Kristen</option>
                                                <option value="Katolik">Katolik</option>
                                                <option value="Hindu">Hindu</option>
                                                <option value="Buddha">Buddha</option>
                                                <option value="Konghucu">Konghucu</option>
                                                <option value="Kepercayaan Lainnya">Kepercayaan Lainnya</option>
                                            </select>
                                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>



                                    </div>
                            </div>

                            <div class="col-sm-12 text-center">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <button type="button" class="btn btn-danger">Batal</button>
                            </div>
                            </form>

                        </div>
                    </div>
                </div>


                <!-- Modal View lokasi -->
                <?php if(isset($lokasi)): ?>
                    <div class="modal fade" id="viewlokasiModal<?php echo e($lokasi->id); ?>" tabindex="-1"
                        aria-labelledby="viewlokasiModalLabel<?php echo e($lokasi->id); ?>" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="viewlokasiModalLabel<?php echo e($lokasi->id); ?>">Detail Lokasi</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>NIP:</strong> <?php echo e($lokasi->nip); ?></p>
                                    <p><strong>Nama:</strong> <?php echo e($lokasi->nama); ?></p>
                                    <p><strong>Jenis Kelamin:</strong> <?php echo e($lokasi->jenis_kelamin); ?></p>
                                    <p><strong>Agama:</strong> <?php echo e($lokasi->agama); ?></p>
                                    <p><strong>Provinsi:</strong> <?php echo e($lokasi->provinsiData->name); ?></p>
                                    <p><strong>Kota/Kabupaten:</strong> <?php echo e($lokasi->kotaData->name); ?></p>
                                    <p><strong>Kecamatan:</strong> <?php echo e($lokasi->kecamatanData->name); ?></p>
                                    <p><strong>Desa:</strong> <?php echo e($lokasi->desaData->name); ?></p>
                                    <!-- Tambahkan detail lainnya sesuai kebutuhan -->
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- Modal Edit lokasi -->
                <?php if(isset($lokasi)): ?>
                    <div class="modal fade" id="editlokasiModal<?php echo e($lokasi->id); ?>" tabindex="-1"
                        aria-labelledby="editlokasiModalLabel<?php echo e($lokasi->id); ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editlokasiModalLabel<?php echo e($lokasi->id); ?>">Edit Mahasiswa
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('superadmin.lokasi.update', ['id' => $lokasi->id])); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="modal-body">
                                        <!-- Form untuk mengedit data lokasi -->
                                        <div class="mb-3">


                                            <!-- Di dalam modal -->
                                            <div class="form-group">
                                                <label class="form-label" for="provinsi<?php echo e($lokasi->id); ?>">Provinsi</label>
                                                <select name="provinsi<?php echo e($lokasi->id); ?>" class="form-select border-success"
                                                    id="provinsi<?php echo e($lokasi->id); ?>">
                                                    <option value="">Pilih Provinsi</option>
                                                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provinsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($provinsi->id); ?>"
                                                            <?php echo e($provinsi->id == $lokasi->provinsi ? 'selected' : ''); ?>>
                                                            <?php echo e($provinsi->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label class="form-label"
                                                    for="kota<?php echo e($lokasi->id); ?>">Kota/Kabupaten</label>
                                                <select name="kota<?php echo e($lokasi->id); ?>" class="form-select border-success"
                                                    id="kota<?php echo e($lokasi->id); ?>">
                                                    <!-- Opsi akan dimuat melalui JavaScript -->
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label class="form-label"
                                                    for="kecamatan<?php echo e($lokasi->id); ?>">Kecamatan</label>
                                                <select name="kecamatan<?php echo e($lokasi->id); ?>"
                                                    class="form-select border-success" id="kecamatan<?php echo e($lokasi->id); ?>">
                                                    <!-- Opsi akan dimuat melalui JavaScript -->
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label class="form-label" for="desa<?php echo e($lokasi->id); ?>">Desa</label>
                                                <select name="desa<?php echo e($lokasi->id); ?>" class="form-select border-success"
                                                    id="desa<?php echo e($lokasi->id); ?>">
                                                    <!-- Opsi akan dimuat melalui JavaScript -->
                                                </select>
                                            </div>


                                            <!-- Form untuk nomor induk pegawai -->
                                            <div class="form-group">
                                                <label class="form-label" for="nipx">Nomor Induk Pegawai:</label>
                                                <input type="number" name="nipx"
                                                    class="form-control border-success <?php $__errorArgs = ['nipx'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="nipx" value="<?php echo e($lokasi->nip); ?>">
                                                <?php $__errorArgs = ['nipx'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <!-- Form untuk nama lengkap -->
                                            <div class="form-group">
                                                <label class="form-label" for="namax">Nama Lengkap:</label>
                                                <input type="text" name="namax"
                                                    class="form-control border-success <?php $__errorArgs = ['namax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="namax" value="<?php echo e($lokasi->nama); ?>">
                                                <?php $__errorArgs = ['namax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <!-- Form untuk nomor handphone -->
                                            <div class="form-group">
                                                <label class="form-label" for="nohpx">Nomor Handphone:</label>
                                                <input type="number" name="nohpx"
                                                    class="form-control border-success <?php $__errorArgs = ['nohpx'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="nohpx" value="<?php echo e($lokasi->nohp); ?>">
                                                <?php $__errorArgs = ['nohpx'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>



                                            <div class="form-group">
                                                <label class="form-label" for="alamatx">Alamat KKN:</label>
                                                <textarea name="alamatx" class="form-control border-success <?php $__errorArgs = ['alamatx'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamatx"><?php echo e($lokasi->alamat); ?></textarea>
                                                <?php $__errorArgs = ['alamatx'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <!-- Form untuk jenis kelamin -->
                                            <label class="form-label">Jenis Kelamin:</label>
                                            <div class="form-group">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="jenis_kelaminx"
                                                        id="laki_lakix" value="laki_laki"
                                                        <?php if($lokasi->jenis_kelamin == 'laki_laki'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="laki_laki">Laki-laki</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="jenis_kelaminx"
                                                        id="perempuanx" value="perempuan"
                                                        <?php if($lokasi->jenis_kelamin == 'perempuan'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="perempuan">Perempuan</label>
                                                </div>
                                            </div>

                                            <!-- Form untuk memilih agama -->
                                            <div class="form-group">
                                                <label class="form-label" for="agamax">Agama</label>
                                                <select name="agamax"
                                                    class="form-select border-success <?php $__errorArgs = ['agamax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    data-trigger id="agamax">
                                                    <option value="">Pilih Agama</option>
                                                    <option value="Islam" <?php if($lokasi->agama == 'Islam'): ?> selected <?php endif; ?>>
                                                        Islam</option>
                                                    <option value="Kristen" <?php if($lokasi->agama == 'Kristen'): ?> selected <?php endif; ?>>
                                                        Kristen</option>
                                                    <option value="Katolik" <?php if($lokasi->agama == 'Katolik'): ?> selected <?php endif; ?>>
                                                        Katolik</option>
                                                    <option value="Hindu" <?php if($lokasi->agama == 'Hindu'): ?> selected <?php endif; ?>>
                                                        Hindu</option>
                                                    <option value="Buddha" <?php if($lokasi->agama == 'Buddha'): ?> selected <?php endif; ?>>
                                                        Buddha</option>
                                                    <option value="Konghucu"
                                                        <?php if($lokasi->agama == 'Konghucu'): ?> selected <?php endif; ?>>Konghucu
                                                    </option>
                                                    <option value="Kepercayaan Lainnya"
                                                        <?php if($lokasi->agama == 'Kepercayaan Lainnya'): ?> selected <?php endif; ?>>Kepercayaan
                                                        Lainnya</option>
                                                </select>
                                                <?php $__errorArgs = ['agamax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Update Data</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- div fb Start -->
    </div>

    <!-- Footer Section Start -->

    <?php echo $__env->make('tampilan_superadmin.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <script>
        $(document).ready(function() {
            // Ajax setup to include CSRF token with every request
            $.ajaxSetup({
                headers: {
                    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                }
            });

            // Event listener for province change
            $('#provinsi').on('change', function() {
                let id_provinsi = $(this).val();

                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(route('superadmin.getkabupaten')); ?>",
                    data: {
                        id_provinsi: id_provinsi
                    },
                    success: function(response) {
                        $('#kota').html(response.options); // Populate regencies dropdown
                        $('#kecamatan')
                            .empty(); // Clear district dropdown when province changes
                        $('#desa').empty(); // Clear village dropdown when province changes
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            // Event listener for regency change
            $('#kota').on('change', function() {
                let id_kota = $(this).val();

                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(route('superadmin.getkecamatan')); ?>",
                    data: {
                        id_kota: id_kota
                    },
                    success: function(response) {
                        $('#kecamatan').html(response.options); // Populate districts dropdown
                        $('#desa').empty(); // Clear village dropdown when regency changes
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            // Event listener for district change
            $('#kecamatan').on('change', function() {
                let id_kecamatan = $(this).val();

                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(route('superadmin.getdesa')); ?>",
                    data: {
                        id_kecamatan: id_kecamatan
                    },
                    success: function(response) {
                        $('#desa').html(response.options); // Populate villages dropdown
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });
    </script>
    <?php if(isset($lokasi)): ?>
        <script>
            $(document).ready(function() {
                // Fungsi untuk memuat data kota/kabupaten saat modal ditampilkan
                function loadRegencies(provinsiId) {
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(route('superadmin.get.regencies')); ?>?provinsi_id=" + provinsiId,
                        success: function(res) {
                            if (res) {
                                $("#kota<?php echo e($lokasi->id); ?>").empty();
                                $("#kota<?php echo e($lokasi->id); ?>").append(
                                    '<option value="">Pilih Kota/Kabupaten</option>');
                                $.each(res, function(key, value) {
                                    $("#kota<?php echo e($lokasi->id); ?>").append('<option value="' + value
                                        .id + '">' + value.name + '</option>');
                                });

                                // Memilih nilai yang sesuai
                                $("#kota<?php echo e($lokasi->id); ?>").val(<?php echo e($lokasi->kota); ?>);
                                loadDistricts(
                                    <?php echo e($lokasi->kota); ?>); // Memuat kecamatan berdasarkan kota yang dipilih
                            } else {
                                $("#kota<?php echo e($lokasi->id); ?>").empty();
                                $("#kecamatan<?php echo e($lokasi->id); ?>").empty(); // Kosongkan dropdown kecamatan
                                $("#desa<?php echo e($lokasi->id); ?>").empty(); // Kosongkan dropdown desa
                            }
                        }
                    });
                }

                // Fungsi untuk memuat data kecamatan saat dipanggil
                function loadDistricts(kotaId) {
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(route('superadmin.get.districts')); ?>?kota_id=" + kotaId,
                        success: function(res) {
                            if (res) {
                                $("#kecamatan<?php echo e($lokasi->id); ?>").empty();
                                $("#kecamatan<?php echo e($lokasi->id); ?>").append(
                                    '<option value="">Pilih Kecamatan</option>');
                                $.each(res, function(key, value) {
                                    $("#kecamatan<?php echo e($lokasi->id); ?>").append('<option value="' +
                                        value.id + '">' + value.name + '</option>');
                                });

                                // Memilih nilai yang sesuai
                                $("#kecamatan<?php echo e($lokasi->id); ?>").val(<?php echo e($lokasi->kecamatan); ?>);
                                loadVillages(
                                    <?php echo e($lokasi->kecamatan); ?>

                                    ); // Memuat desa berdasarkan kecamatan yang dipilih
                            } else {
                                $("#kecamatan<?php echo e($lokasi->id); ?>").empty();
                                $("#desa<?php echo e($lokasi->id); ?>").empty(); // Kosongkan dropdown desa
                            }
                        }
                    });
                }

                // Fungsi untuk memuat data desa saat dipanggil
                function loadVillages(kecamatanId) {
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(route('superadmin.get.villages')); ?>?kecamatan_id=" + kecamatanId,
                        success: function(res) {
                            if (res) {
                                var desaSelect = $("#desa<?php echo e($lokasi->id); ?>");
                                desaSelect.empty().append('<option value="">Pilih Desa</option>');
                                $.each(res, function(key, value) {
                                    desaSelect.append('<option value="' + value.id + '">' + value
                                        .name + '</option>');
                                });

                                // Memilih nilai yang sesuai setelah opsi desa dimuat
                                $("#desa<?php echo e($lokasi->id); ?>").val(<?php echo e($lokasi->desa); ?>);
                            } else {
                                $("#desa<?php echo e($lokasi->id); ?>").empty();
                            }
                        }
                    });
                }

                // Memuat data kota/kabupaten saat modal ditampilkan
                var provinsiId = $("#provinsi<?php echo e($lokasi->id); ?>").val();
                if (provinsiId) {
                    loadRegencies(provinsiId);
                }

                // Menangani perubahan provinsi
                $('#provinsi<?php echo e($lokasi->id); ?>').change(function() {
                    var provinsiId = $(this).val();
                    if (provinsiId) {
                        loadRegencies(provinsiId);
                    } else {
                        $("#kota<?php echo e($lokasi->id); ?>").empty();
                        $("#kecamatan<?php echo e($lokasi->id); ?>").empty(); // Kosongkan dropdown kecamatan
                        $("#desa<?php echo e($lokasi->id); ?>").empty(); // Kosongkan dropdown desa
                    }
                });

                // Menangani perubahan kota/kabupaten
                $('#kota<?php echo e($lokasi->id); ?>').change(function() {
                    var kotaId = $(this).val();
                    if (kotaId) {
                        loadDistricts(kotaId);
                    } else {
                        $("#kecamatan<?php echo e($lokasi->id); ?>").empty();
                        $("#desa<?php echo e($lokasi->id); ?>").empty(); // Kosongkan dropdown desa
                    }
                });

                // Menangani perubahan kecamatan
                $('#kecamatan<?php echo e($lokasi->id); ?>').change(function() {
                    var kecamatanId = $(this).val();
                    if (kecamatanId) {
                        loadVillages(kecamatanId);
                    } else {
                        $("#desa<?php echo e($lokasi->id); ?>").empty();
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                // Tambahkan kelas blink setiap 1 detik
                setInterval(function() {
                    $('#aktif option:selected').toggleClass('blink');
                }, 1000);
            });
        </script>
    <?php endif; ?>
    <script src="/admin/js/plugins/fslightbox.js" defer></script>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_superadmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gituhub\aplikasi-sistem-informasi-kkn\resources\views/SuperAdmin/lokasi.blade.php ENDPATH**/ ?>