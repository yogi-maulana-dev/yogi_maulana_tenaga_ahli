<?php echo $__env->make('tampilan_dosen.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_dosen.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('tampilan_dosen.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_dosen.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('home'); ?>
<?php echo $__env->yieldContent('kegiatan'); ?>
<?php echo $__env->yieldContent('kelompok'); ?>
<?php echo $__env->yieldContent('proposal'); ?>
<?php echo $__env->yieldContent('absen'); ?>
<?php echo $__env->yieldContent('profil'); ?>
<?php echo $__env->yieldContent('peringatan'); ?>
<?php echo $__env->yieldContent('edit-profil'); ?>
<?php echo $__env->make('tampilan_dosen.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_dosen.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/kkn.uml.my.id/resources/views/tampilan_dosen/index.blade.php ENDPATH**/ ?>