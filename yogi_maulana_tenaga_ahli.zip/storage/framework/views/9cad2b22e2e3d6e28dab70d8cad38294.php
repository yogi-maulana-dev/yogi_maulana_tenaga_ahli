
<?php $__env->startSection('peringatan'); ?>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-warning">Peringatann !!!
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">
                                <div class="alert alert-danger mt-4">
                               <h4 class="card-title text-danger">Yang dapat input tugas hanya ketua, jika anda belum menjadi ketua silakan hubungi admin !!
                                            </h4>
                                </div>
                      
                                
                            </div>
                        </div>

                    

                    </div>

                   
                </div>
            </div>

        </div>

    </div>
  





    <!-- Footer Section Start -->
    <?php echo $__env->make('tampilan_mhs.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Section End -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_mhs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gituhub\aplikasi-sistem-informasi-kkn\resources\views/Mahasiswa/peringatan.blade.php ENDPATH**/ ?>