
<?php $__env->startSection('tugas'); ?>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4"><?php echo e(Auth::guard('web')->user()->namalengkap); ?></h4>

                                </div>
                            </div>
                            <ul class="d-flex nav nav-pills mb-0 text-center profile-tab" data-toggle="slider-tab"
                                id="profile-pills-tab" role="tablist">
                                
                                <li class="nav-item">
                                    <a class="nav-link active show" data-bs-toggle="tab" href="#profile-activity"
                                        role="tab" aria-selected="false">Kegiatan Harian</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#profile-profile" role="tab"
                                        aria-selected="false">Profile</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <p>Apa yang anda dan Kelompok ada lakukan hari ini
                                ?</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-success">Apa yang anda dan Kelompok ada lakukan hari ini ?
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="d-flex align-items-center justify-content-between position-relative">
                                    <?php if(!$tugas->isEmpty()): ?>
                                        <!-- Tampilkan formulir untuk mengupload tugas -->
                                        <div class="col-md-4">
                                            <div class="card mb-4">
                                                <div class="card-body">
                                                    <p>Deadline: <span id="waktuMundur"></span></p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Tambahkan skrip JavaScript untuk menghitung waktu mundur -->
                                    <?php else: ?>
                         
                                            <div class="col-lg-12">
                                                <form action="<?php echo e(route('tugas.simpan')); ?>" method="post"
                                                    enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label for="gambar" class="form-label custom-file-input">Upload
                                                            Foto
                                                            Kegiatan</label>
                                                        <input
                                                            class="form-control border-success <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            name="gambar" type="file" id="gambar">
                                                        <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <textarea class="form-control border-success <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="keterangan"
                                                            id="exampleFormControlTextarea1" cols="120" rows="10"></textarea>
                                                        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <button type="submit" class="btn bg-success text-white">Upload
                                                        Tugas</button>
                                                </form>
                                            </div>
                                   
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-success">Tugas yang sudah dilakukan ?
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">
                                <div
                                    class="iq-timeline0 m-0 d-flex align-items-center justify-content-between position-relative">
                                    <ul class="list-inline p-0 m-0">
                                        
                                        <?php if($tabungtugas->isNotEmpty()): ?>
                                            
                                            <li>
                                                <div class="timeline-dots timeline-dot1 border-primary text-primary">
                                                </div>
                                                <h6 class="float-left mb-1">Hari 1</h6>
                                                <small
                                                    class="float-right mt-1"><?php echo e($tabungtugas->first()->created_at->format('d F Y')); ?></small>
                                                <div class="d-inline-block w-100">
                                                    <p><?php echo e($tabungtugas->first()->tugas); ?></p>
                                                </div>
                                            </li>

                                            
                                            <?php $__currentLoopData = $tabungtugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tabungtugasx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key > 0): ?>
                                                    <li>
                                                        <div
                                                            class="timeline-dots timeline-dot1 border-primary text-primary">
                                                        </div>
                                                        <h6 class="float-left mb-1">Hari <?php echo e($key + 1); ?></h6>
                                                        <small
                                                            class="float-right mt-1"><?php echo e($tabungtugasx->created_at->addDays($key)->format('d F Y')); ?></small>
                                                        <div class="d-inline-block w-100">
                                                            <p><?php echo e($tabungtugasx->tugas); ?></p>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            
                                            <li>Data tidak tersedia.</li>
                                        <?php endif; ?>
                                    </ul>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua kelompok akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">KKN KELOMPOK ? TAHUN ?</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="user-bio">
                                    <p>Tart I love sugar plum I love oat cake. Sweet roll caramels I love jujubes.
                                        Topping cake wafer.</p>
                                </div>
                                <div class="mt-2">
                                    <h6 class="mb-1">Joined:</h6>
                                    <p>Feb 15, 2021</p>
                                </div>
                                <div class="mt-2">
                                    <h6 class="mb-1">Lives:</h6>
                                    <p>United States of America</p>
                                </div>
                                <div class="mt-2">
                                    <h6 class="mb-1">Email:</h6>
                                    <p><a href="#" class="text-body"> austin@gmail.com</a></p>
                                </div>
                                <div class="mt-2">
                                    <h6 class="mb-1">Url:</h6>
                                    <p><a href="#" class="text-body" target="_blank"> www.bootstrap.com </a>
                                    </p>
                                </div>
                                <div class="mt-2">
                                    <h6 class="mb-1">Contact:</h6>
                                    <p><a href="#" class="text-body">(001) 4544 565 456</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
    <script>
        <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugasx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            // Ambil waktu tugas dibuat
            var created_at = new Date("<?php echo e($tugasx->created_at); ?>");

            // Set waktu target (23:59:00)
            var deadline = new Date(created_at);
            deadline.setHours(23);
            deadline.setMinutes(59);
            deadline.setSeconds(30);

            // Update status dan tampilkan waktu mundur menggunakan JavaScript
            var interval = setInterval(function() {
                var now = new Date();
                var difference = deadline - now;

                if (difference <= 0) {
                    // Waktu habis, update status dan hentikan interval
                    clearInterval(interval);
                    $.ajax({
                        url: "<?php echo e(route('updateStatus', $tugasx->id)); ?>",
                        type: "GET",
                        success: function(response) {
                            console.log(response.message);
                            window.location.href = "<?php echo e(route('tugas')); ?>";
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                } else {
                    // Hitung sisa waktu mundur
                    var remainingTime = new Date(difference);

                    // Ambil jam, menit, dan detik dari sisa waktu mundur
                    var hours = remainingTime.getUTCHours();
                    var minutes = remainingTime.getUTCMinutes();
                    var seconds = remainingTime.getUTCSeconds();

                    // Format output waktu mundur
                    var displayTime = hours + " jam " + minutes + " menit " + seconds + " detik ";
                    $("#waktuMundur").text(displayTime);
                }
            }, 1000);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>





    <!-- Footer Section Start -->
    <?php echo $__env->make('tampilan_mhs.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Section End -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_mhs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gituhub\aplikasi-sistem-informasi-kkn\resources\views/Mahasiswa/tugas.blade.php ENDPATH**/ ?>