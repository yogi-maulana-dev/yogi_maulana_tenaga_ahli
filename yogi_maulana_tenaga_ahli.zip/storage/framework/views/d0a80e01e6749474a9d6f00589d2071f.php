
<?php $__env->startSection('proposal'); ?>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4"><?php echo e(Auth::guard('web')->user()->namalengkap); ?></h4>

                                </div>
                            </div>
                            <ul class="d-flex nav nav-pills mb-0 text-center profile-tab" data-toggle="slider-tab"
                                id="profile-pills-tab" role="tablist">
                                
                                <li class="nav-item">
                                    <a class="nav-link active show" data-bs-toggle="tab" href="#profile-activity"
                                        role="tab" aria-selected="false">Kegiatan Harian</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#profile-profile" role="tab"
                                        aria-selected="false">Profile</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <p>Apa yang anda dan Kelompok ada lakukan hari ini 
                                ?</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-success">Apa yang anda dan Kelompok ada lakukan hari ini ? 
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="d-flex align-items-center justify-content-between position-relative">
                             
                                    <?php if($proposal->isEmpty()): ?>
    <div class="col-lg-12">
        <form action="<?php echo e(route('proposal.simpan')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="file" class="form-label">Upload Foto Kegiatan</label>
                <input class="form-control border-success <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file" type="file" id="file" accept="application/pdf">
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="exampleFormControlTextarea1" class="form-label">Keterangan</label>
                <textarea class="form-control border-success <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="keterangan" id="exampleFormControlTextarea1" cols="30" rows="10"></textarea>
                <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn bg-success text-white">Upload Tugas</button>
        </form>
    </div>
<?php else: ?>
    <?php $__currentLoopData = $proposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->status == '0'): ?>
        <div class="col-md-12">
            <div class="card mb-12">
                <div class="card-body">
                    <p>Deadline: <span id="waktuMundur"></span></p>
                </div>
            </div>
        </div>
        <?php elseif($item->status == '2'): ?>
            dasd
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

                              
                                
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-success">Tugas yang sudah dilakukan ?
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">
                                <div
                                    class="iq-timeline0 m-0 d-flex align-items-center justify-content-between position-relative">
                                    <ul class="list-inline p-0 m-0">
                                        
                                        <?php if($proposal->isNotEmpty()): ?>
                                            
                                            <li>
                                                <div class="timeline-dots timeline-dot1 border-primary text-primary">
                                                </div>
                                                <h6 class="float-left mb-1">Hari 1</h6>
                                                <small
                                                    class="float-right mt-1"><?php echo e($proposal->first()->created_at->format('d F Y')); ?></small>
                                                <div class="d-inline-block w-100">
                                                    <p><?php echo e($proposal->first()->tugas); ?></p>
                                                </div>
                                            </li>

                                            
                                            <?php $__currentLoopData = $proposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $proposalx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key > 0): ?>
                                                    <li>
                                                        <div
                                                            class="timeline-dots timeline-dot1 border-primary text-primary">
                                                        </div>
                                                        <h6 class="float-left mb-1">Hari <?php echo e($key + 1); ?></h6>
                                                        <small
                                                            class="float-right mt-1"><?php echo e($proposalx->created_at->addDays($key)->format('d F Y')); ?></small>
                                                        <div class="d-inline-block w-100">
                                                            <p><?php echo e($proposalx->tugas); ?></p>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            
                                            <li>Data tidak tersedia.</li>
                                        <?php endif; ?>
                                    </ul>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua kelompok akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                  
                    </div>
                </div>
            </div>

        </div>

    </div>
    <script>
        var statusUpdated = false; // Variabel untuk menandai apakah status sudah diupdate
    
        <?php $__currentLoopData = $proposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposalx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var proposalStatus = "<?php echo e($proposalx->status); ?>";
    
            if (proposalStatus === '0') {
                // Ambil waktu tugas dibuat
                var created_at = new Date("<?php echo e($proposalx->created_at); ?>");
    
                // Set waktu target (23:59:00)
                // var deadline = new Date("2024-04-17T19:59:00"); // Format tanggal: tahun-bulan-tanggalTjam:menit:detik
                var deadline = new Date(created_at);
                deadline.setHours(23);
                deadline.setMinutes(59);
                deadline.setSeconds(30);

                // Update status dan tampilkan waktu mundur menggunakan JavaScript
                var interval = setInterval(function() {
                    var now = new Date(); // Format tanggal: tahun-bulan-tanggalTjam:menit:detik
                    var difference = deadline - now;
    
                    if (difference <= 0 && !statusUpdated) {
                        // Waktu habis, update status dan tampilkan pesan
                        clearInterval(interval);
                        $.ajax({
                            url: "<?php echo e(route('updateproposal', $proposalx->id)); ?>",
                            type: "GET",
                          
                            success: function(response) {
                                console.log(response.message);
                                // Tidak lakukan redirect jika sudah diupdate
                            },
                            error: function(xhr, status, error) {
                                console.error(xhr.responseText);
                            }
                        });
                    } else {
                        // Hitung sisa waktu mundur
                        var remainingTime = new Date(difference);
    
                        // Ambil jam, menit, dan detik dari sisa waktu mundur
                        var hours = remainingTime.getUTCHours();
                        var minutes = remainingTime.getUTCMinutes();
                        var seconds = remainingTime.getUTCSeconds();
    
                        // Format output waktu mundur
                        var displayTime = hours + " jam " + minutes + " menit " + seconds + " detik ";
                        $("#waktuMundur").text(displayTime);
                    }
                }, 1000);
            }
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
    





    <!-- Footer Section Start -->
    <?php echo $__env->make('tampilan_mhs.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Section End -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_mhs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gituhub\aplikasi-sistem-informasi-kkn\resources\views/Mahasiswa/proposal.blade.php ENDPATH**/ ?>