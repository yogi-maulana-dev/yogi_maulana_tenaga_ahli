
<?php $__env->startSection('kegiatan'); ?>

    <style>
        .btn-group .btn {
            margin-right: 5px;
        }

        .modal-body {
            background-color: #e8e8e8;
            padding: 20px;
        }

        .kartu {
            width: 800px;
            margin: 0 auto;
            margin-top: 5px;
            box-shadow: 0 0.25rem 0.75rem rgba(0, 0, 0, .03);
            transition: all .3s;
        }

        .foto {
            padding: 20px;
        }

        .modal-body tbody {
            font-size: 20px;
            font-weight: 300;
        }

        .biodata {
            margin-top: 30px;
        }
    </style>

    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <!-- Add other images if necessary -->
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4"><?php echo e(Auth::guard('dosen')->user()->namalengkap); ?></h4>
                                    <span> - Super Admin</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">
                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Data Kegiatan Kelompok
                                        <span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                            <?php $__currentLoopData = $kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($item->nokelompok); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                    </h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-4">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success mt-4">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-warning mt-4">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="table-responsive">
                                    <table id="example" class="stripe hover"
                                        style="width:100%; padding-top: 1em; padding-bottom: 1em;">
                                        <thead>
                                            <tr>
                                                <th>Foto</th>
                                                <th>Kelompok</th>
                                                <th>Waktu Mengirim</th>
                                                <th>Periksa</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $allkegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td style="max-width: 100px;">
                                                        <a data-fslightbox="gallery"
                                                            href="<?php echo e(url($kegiatan->fotokegiatan)); ?>">
                                                            <img src="<?php echo e(url($kegiatan->fotokegiatan)); ?>"
                                                                class="img-fluid bg-soft-primary rounded w-100 h-100"
                                                                alt="profile-image" loading="lazy">
                                                        </a>
                                                    </td>
                                                    <td><?php echo e($kegiatan->kelompoktugas); ?></td>
                                                    <td><?php echo e(\Carbon\Carbon::parse($kegiatan->created_at)->format('d F Y H:i:s')); ?>

                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-primary"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#editKegiatanModal<?php echo e($kegiatan->id); ?>">
                                                            Edit
                                                        </button>
                                                    </td>
                                                    <td>
                                                        <?php if($kegiatan->status == '2'): ?>
                                                            <h5 class="text-success">Sudah Diperiksa</h5>
                                                        <?php else: ?>
                                                            <h5 class="text-warning">Belum Diperiksa</h5>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Foto</th>
                                                <th>Kelompok</th>
                                                <th>Waktu Mengirim</th>
                                                <th>Status</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">
                                    <div class="mt-3">
                                        <p class="d-inline-block pl-3">- Perhatikan untuk ketua kelompok akan dipilih dengan
                                            mengisi form data diri lalu diberikan kepada admin, membawa bukti pembayaran.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            <!-- Modal Edit Kegiatan -->
            <?php $__currentLoopData = $allkegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatanedit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="editKegiatanModal<?php echo e($kegiatanedit->id); ?>" tabindex="-1"
                    aria-labelledby="editKegiatanModalLabel<?php echo e($kegiatanedit->id); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editKegiatanModalLabel<?php echo e($kegiatanedit->id); ?>">Edit Kegiatan
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="editForm<?php echo e($kegiatanedit->id); ?>" action="<?php echo e(route('dosen.kegiatanedit.update', ['id' => $kegiatanedit->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="mb-3">
                                        <label for="kelompoktugas" class="form-label">Kelompok Tugas</label>
                                        <input type="text" class="form-control" id="kelompoktugas" name="kelompoktugas"
                                            value="<?php echo e($kegiatanedit->kelompoktugas); ?>">
                                    </div>

                                    <div class="form-group">
                                         <label for="kelompoktugas" class="form-label">Foto Kegiatan</label>
                                        <div class="grid grid-cols-3 gap-4">
                                            <a data-fslightbox="gallery" href="<?php echo e(url($kegiatanedit->fotokegiatan)); ?>">
                                                <img src="<?php echo e(url($kegiatanedit->fotokegiatan)); ?>"
                                                    class="img-fluid bg-soft-primary rounded"
                                                    style="width: 200px; height:200px; object-fit:cover;"
                                                    alt="profile-image" loading="lazy">
                                            </a>
                                        </div>
                                    </div>

                                        <div class="form-group">
                                                   <label for="kelompoktugas" class="form-label">Ubah Status Kegiatan</label>
                                        <div class="grid grid-cols-3 gap-4">
                                            <select name="status" 
                                                style="color: <?php echo e($kegiatanedit->status == '2' ? 'green' : ($kegiatanedit->status == '0' ? 'red' : 'black')); ?>">
                                                <option value="">==Silakan Pilih Status==</option>
                                                <option value="2" <?php echo e($kegiatanedit->status == '2' ? 'selected' : ''); ?>>Sudah Periksa</option>
                                                <option value="0" <?php echo e($kegiatanedit->status == '0' ? 'selected' : ''); ?>>Belum Diperikasa</option>
                                            </select>
                                        </div>
                                    </div>
                                    

                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary save-btn"
                                    data-form-id="<?php echo e($kegiatanedit->id); ?>">Simpan Status Kegiatan</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <?php echo $__env->make('tampilan_dosen.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function() {
            $('.save-btn').click(function() {
                var formId = $(this).data('form-id');
                $('#editForm' + formId).submit();
            });
        });
    </script>

    <script src="/admin/js/plugins/fslightbox.js" defer></script>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_dosen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/kkn.uml.my.id/resources/views/Dosen/kegiatan.blade.php ENDPATH**/ ?>