

    <!-- loader Start -->
    <div id="loading">
        <div class="loader simple-loader">
            <div class="loader-body">
                <img src="https://templates.iqonic.design/hope-ui/pro/html/assets/images/loader.webp" alt="loader"
                    class="light-loader img-fluid w-25" width="200" height="200" />
            </div>
        </div>
    </div>
    <!-- loader END --><?php /**PATH /home/u1711091/public_html/kkn.uml.my.id/resources/views/tampilan_superadmin/loading.blade.php ENDPATH**/ ?>