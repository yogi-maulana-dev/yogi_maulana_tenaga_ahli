<?php $__env->startSection('dashboard'); ?>
<div class="content-inner container-fluid pb-0" id="page_layout">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title">
                            <?php echo e($judul); ?>

                        </h4>
                    </div>
                </div>
                <div class="card-body">
                    <p class="mb-3">
                     Dasboard Admin
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
        
        <!-- Footer Section Start -->
        <?php echo $__env->make('tampilan_superadmin.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer Section End -->
    </main>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_superadmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projetyai\kknlo\yogi\yogi_maulana_tenaga_ahli\resources\views/SuperAdmin/dashboard.blade.php ENDPATH**/ ?>