<?php $__env->startSection('kelompok'); ?>

    <style>
        .btn-group .btn {
            margin-right: 5px;
            /* Sesuaikan dengan jarak yang Anda inginkan */
        }

        /* Add this CSS in your HTML file or in your stylesheet */
        .modal-body {
            background-color: #e8e8e8;
            /* Set background color */
            padding: 20px;
            /* Add padding */
        }

        .kartu {
            width: 800px;
            /* Set modal width */
            margin: 0 auto;
            /* Center modal horizontally */
            margin-top: 5px;
            /* Adjust top margin */
            box-shadow: 0 0.25rem 0.75rem rgba(0, 0, 0, .03);
            /* Add box shadow */
            transition: all .3s;
            /* Add transition effect */
        }

        .foto {
            padding: 20px;
            /* Add padding */
        }

        .modal-body tbody {
            font-size: 20px;
            /* Set font size */
            font-weight: 300;
            /* Set font weight */
        }

        .biodata {
            margin-top: 30px;
            /* Adjust top margin */
        }
    </style>

    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4"><?php echo e(Auth::guard('dosen')->user()->namalengkap); ?></h4>
                                    <span> - Super Admin</span>
                                </div>
                            </div>
                    
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Data Absen Kegiatan Kelompok </h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-4">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success mt-4">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-warning mt-4">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="table-responsive">
                                    <table id="example" class="stripe hover"
                                        style="width:100%; padding-top: 1em; padding-bottom: 1em;">
                                        <thead>
                                            <tr>
                                                <th>Kelompok</th>
                                                <th>NPM Ketua</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $allkelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelompok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($kelompok->nokelompok); ?></td>
                                                    <td><?php echo e($kelompok->npm); ?></td>
                                                    <td>    <a href="/dosen/kelompok/kegiatan/<?php echo e($kelompok->nokelompok); ?>" class="btn btn-sm btn-primary cetak-btn">
                                                      Lihat Kegiatan
                                                    </a>
                                                    <a href="/dosen/kelompok/absen/<?php echo e($kelompok->nokelompok); ?>" class="btn btn-sm btn-success">
                                                        Lihat Absen
                                                    </a>

                                                    <a href="/dosen/kelompok/proposal/<?php echo e($kelompok->nokelompok); ?>" class="btn btn-sm btn-success">
                                                        Lihat Proposal
                                                    </a>
                                                </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Kelompok</th>
                                                <th>NPM Ketua</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>

                            </div>

                            <!-- Modal Edit Mahasiswa -->

                        </div>

                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua kelompok akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                 
                    </div>
                    <!-- Modal Edit Mahasiswa -->
                </div>
            </div>

        </div>
        <!-- div fb Start -->
    </div>

    <!-- Footer Section Start -->

    <?php echo $__env->make('tampilan_dosen.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script>
        $(document).ready(function() {
            $('.save-btn').click(function() {
                var formId = $(this).data('form-id');
                $('#editForm' + formId).submit();
            });
        });
    </script>



    <script src="/admin/js/plugins/fslightbox.js" defer></script>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_dosen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gituhub\aplikasi-sistem-informasi-kkn\resources\views/Dosen/kelompok.blade.php ENDPATH**/ ?>