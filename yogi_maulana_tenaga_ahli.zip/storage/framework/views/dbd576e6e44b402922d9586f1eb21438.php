
<?php $__env->startSection('peringatan'); ?>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-warning">Peringatann !!!
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">

                                <?php if(session('warning')): ?>
                                    <div class="alert alert-warning mt-4">
                                        <?php echo e(session('warning')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-warning mt-4">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>

                            </div>


                        </div>
                    </div>
                </div>


            </div>
        </div>

    </div>

    </div>

    <!-- Footer Section Start -->
    <?php echo $__env->make('tampilan_mhs.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Section End -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_mhs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/kkn.uml.my.id/resources/views/Mahasiswa/peringatan.blade.php ENDPATH**/ ?>