
# Selamat Datang, Admin!



Anda telah menerima token baru untuk menggati password. Silakan gunakan token berikut untuk login:
<div style="border: 1px solid #ddd; padding: 10px; background-color: #f9f9f9;">
    <?php echo e($token); ?>

</div>
Jangan berikan token ini kepada siapapun. Terima kasih!<br>



Terima kasih,<br>



<?php $__env->startPush('css'); ?>
    <style>
        /* Tambahkan gaya CSS sesuai kebutuhan */
        body {
            font-family: 'Arial', sans-serif;
        }

        h1 {
            color: #333;
        }

        /* Tambahkan gaya CSS lainnya */
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\projetyai\kknlo\resources\views/mails/superadmin_token.blade.php ENDPATH**/ ?>