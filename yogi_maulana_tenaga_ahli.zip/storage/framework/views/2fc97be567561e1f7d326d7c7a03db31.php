<?php $__env->startSection('proposal'); ?>

    <style>
        .btn-group .btn {
            margin-right: 5px;
            /* Sesuaikan dengan jarak yang Anda inginkan */
        }

        /* Add this CSS in your HTML file or in your stylesheet */
        .modal-body {
            background-color: #e8e8e8;
            /* Set background color */
            padding: 20px;
            /* Add padding */
        }

        .kartu {
            width: 800px;
            /* Set modal width */
            margin: 0 auto;
            /* Center modal horizontally */
            margin-top: 5px;
            /* Adjust top margin */
            box-shadow: 0 0.25rem 0.75rem rgba(0, 0, 0, .03);
            /* Add box shadow */
            transition: all .3s;
            /* Add transition effect */
        }

        .foto {
            padding: 20px;
            /* Add padding */
        }

        .modal-body tbody {
            font-size: 20px;
            /* Set font size */
            font-weight: 300;
            /* Set font weight */
        }

        .biodata {
            margin-top: 30px;
            /* Adjust top margin */
        }
    </style>

    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4"><?php echo e(Auth::guard('dosen')->user()->namalengkap); ?></h4>
                                    <span> - Super Admin</span>
                                </div>
                            </div>
                    
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <div class="header-title">
                                        <h4 class="card-title">Data proposal Kelompok 
                                            <span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                        <?php $__currentLoopData = $kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item->nokelompok); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                        </span></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-4">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success mt-4">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-warning mt-4">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="table-responsive">
                                    <table id="example" class="stripe hover"
                                        style="width:100%; padding-top: 1em; padding-bottom: 1em;">
                                        <thead>
                                            <tr>
                                                <th>Foto</th>
                                                <th>Kelompok</th>
                                                <th>Waktu Mengirim</th>
                                                <th>Status</th>
                                                <th>Periksa</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $allproposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td style="max-width: 100px;">
                                                        <div class="grid grid-cols-3 gap-4">
                                                            <a href="<?php echo e(url($proposal->file)); ?>" target="_blank">Proposal Kelompok <?php echo e($proposal->kelompoktugas); ?></a>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($proposal->kelompoktugas); ?></td>
                                                    
                                                    <td>
                                                        <?php echo e(\Carbon\Carbon::parse($proposal->created_at)->format('d F Y H:i:s')); ?>

                                                    </td>
                                                    
                                                    <td>
                                                        <?php if($proposal->status == '2'): ?>
                                                            <h5 class="text-success">Sudah Diperiksa</h5>
                                                        <?php else: ?>
                                                            <h5 class="text-warning">Belum Diperiksa</h5>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editproposalModal<?php echo e($proposal->id); ?>">
                                                            Edit
                                                        </button>
                                                    </td>
                                                    
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Foto</th>
                                                <th>Kelompok</th>
                                                <th>Waktu Mengirim</th>
                                                <th>Status</th>
                                                <th>Periksa</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>

                            </div>

                            <!-- Modal Edit Mahasiswa -->

                        </div>

                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua kelompok akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                 
                    </div>
                    <!-- Modal Edit Mahasiswa -->

                    <!-- Modal Edit proposal -->
                    <?php $__currentLoopData = $allproposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="modal fade" id="editproposalModal<?php echo e($proposal->id); ?>" tabindex="-1" aria-labelledby="editproposalModalLabel<?php echo e($proposal->id); ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editproposalModalLabel<?php echo e($proposal->id); ?>">Edit Mahasiswa</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('dosen.proposal.update', ['id' => $proposal->id])); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="modal-body">
                                        <!-- Form untuk mengedit data proposal -->
                                        <div class="mb-3">
                                            <div class="form-group">
                                                <label for="kelompoktugas">Nomor Kelompok</label>
                                                <input type="text" class="form-control border-success" id="kelompoktugas" name="kelompoktugas" value="<?php echo e(old('kelompoktugas', $proposal->kelompoktugas)); ?>" readonly>
                                            </div>
                                            <div class="form-group">
                                                <div class="grid grid-cols-3 gap-4">
                                                    <a href="<?php echo e(url($proposal->file)); ?>" target="_blank">Proposal Kelompok <?php echo e($proposal->kelompoktugas); ?></a>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="nip">Nomor Kelompok</label>
                                                <textarea class="form-control border-success" name="keterangan" id="keterangan" rows="4" cols="50"><?php echo e($proposal->keterangan); ?></textarea>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Update Data</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                </div>
            </div>
        </div>
        <!-- div fb Start -->
    </div>

    <!-- Footer Section Start -->

    <?php echo $__env->make('tampilan_dosen.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script>
        $(document).ready(function() {
            $('.edit-mahasiswa').click(function() {
                var mahasiswaId = $(this).data('id');

                // Request data mahasiswa ke server
                $.ajax({
                    type: 'GET',
                    url: '/proposal/mahasiswa/' + mahasiswaId + '/edit',
                    success: function(response) {
                        // Mengisi nilai input fields di modal dengan data mahasiswa yang diterima
                        $('#editMahasiswaId').val(response.id);
                        $('#editNpm').val(response.npm);
                        $('#editNamalengkap').val(response.nama_lengkap);
                        $('#editEmail').val(response.email);
                        $('#editJk').val(response.jenis_kelamin);
                        $('#editNohp').val(response.nohp);
                        $('#editAlamat').val(response.alamat);
                        $('#editFakultas').val(response.fakultas);
                        $('#editJurusan').val(response.jurusan);

                        // Menampilkan modal
                        $('#editMahasiswaModal').modal('show');
                    }
                });
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $('.save-btn').click(function() {
                var formId = $(this).data('form-id');
                $('#editForm' + formId).submit();
            });
        });
    </script>



    <script src="/admin/js/plugins/fslightbox.js" defer></script>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_dosen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gituhub\aplikasi-sistem-informasi-kkn\resources\views/Dosen/proposal.blade.php ENDPATH**/ ?>