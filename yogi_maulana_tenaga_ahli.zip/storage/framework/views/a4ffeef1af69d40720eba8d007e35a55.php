<?php echo $__env->make('tampilan_mhs.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_mhs.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('tampilan_mhs.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_mhs.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('dashboard'); ?>
<?php echo $__env->yieldContent('tugas'); ?>
<?php echo $__env->yieldContent('profil'); ?>
<?php echo $__env->yieldContent('peringatan'); ?>
<?php echo $__env->yieldContent('edit-profil'); ?>
<?php echo $__env->yieldContent('proposal'); ?>
<?php echo $__env->make('tampilan_mhs.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_mhs.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projetyai\kknlo\resources\views/tampilan_mhs/index.blade.php ENDPATH**/ ?>