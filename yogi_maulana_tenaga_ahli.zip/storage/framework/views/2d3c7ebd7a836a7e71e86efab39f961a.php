<?php echo $__env->make('tampilan_superadmin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_superadmin.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('tampilan_superadmin.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_superadmin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('dashboard'); ?>
<?php echo $__env->yieldContent('profil'); ?>
<?php echo $__env->yieldContent('edit-profil'); ?>
<?php echo $__env->yieldContent('lokasi'); ?>
<?php echo $__env->yieldContent('mahasiswa'); ?>
<?php echo $__env->yieldContent('dosen'); ?>
<?php echo $__env->yieldContent('kelompok'); ?>
<?php echo $__env->yieldContent('kelompok-edit'); ?>
<?php echo $__env->yieldContent('dpl'); ?>
<?php echo $__env->yieldContent('tesedit'); ?>
<?php echo $__env->yieldContent('setting'); ?>
<?php echo $__env->yieldContent('nilai'); ?>
<?php echo $__env->make('tampilan_superadmin.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('tampilan_superadmin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projetyai\kknlo\yogi\yogi_maulana_tenaga_ahli\resources\views/tampilan_superadmin/index.blade.php ENDPATH**/ ?>