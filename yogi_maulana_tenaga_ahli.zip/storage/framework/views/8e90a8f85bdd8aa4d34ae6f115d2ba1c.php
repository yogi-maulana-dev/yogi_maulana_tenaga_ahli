<?php $__env->startSection('setting'); ?>
    <style>
        /* Blink animation */
        @keyframes blink {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        .blink {
            animation: blink 1s infinite;
        }
    </style>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4"><?php echo e(Auth::guard('superadmin')->user()->namalengkap); ?></h4>
                                    <span> - SuperAdmin</span>
                                </div>
                            </div>
                            <ul class="d-flex nav nav-pills mb-0 text-center profile-tab" data-toggle="slider-tab"
                                id="profile-pills-tab" role="tablist">
                                
                                <li class="nav-item">
                                    <a class="nav-link active show" data-bs-toggle="tab" href="#profile-activity"
                                        role="tab" aria-selected="false">Profil Admin</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#setting" role="tab"
                                        aria-selected="false">Setting Website</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">


                        <div class="card">
                            <div class="card-body">

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-4">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success mt-4">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-warning mt-4">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>

                                <p class="mb-3">
                                    <?php if($allsettingadmin): ?>
                                        <form
                                            action="<?php echo e(route('superadmin.settingadmin.update', ['id' => $allsettingadmin->id])); ?>"
                                            method="POST" enctype="multipart/form-data" id="tokenForm">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="form-label" for="namalengkap">Nama Lengkap:</label>
                                                    <input type="text" name="namalengkap"
                                                        class="form-control border-success <?php $__errorArgs = ['namalengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="namalengkap"
                                                        value="<?php echo e(old('namalengkap') ?? ($allsettingadmin->namalengkap ?? '')); ?>">
                                                    <?php $__errorArgs = ['namalengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="email">Email:</label>
                                                    <input type="email" name="email"
                                                        class="form-control border-success <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="email"
                                                        value="<?php echo e(old('email') ?? ($allsettingadmin->email ?? '')); ?>">
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="nohp">Nomor HandPhone:</label>
                                                    <input type="text" name="nohp"
                                                        class="form-control border-success <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="nohp"
                                                        value="<?php echo e(old('nohp') ?? ($allsettingadmin->nohp ?? '')); ?>">
                                                    <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="password">Password Ganti:</label>
                                                    <input type="text" name="password"
                                                        class="form-control border-success <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="password" value="<?php echo e(old('password')); ?>">
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="token" class="form-label">Token</label>
                                                    <div class="input-group">
                                                        <input type="text" name="token" id="token"
                                                            class="form-control border-success">
                                                        <div class="input-group-append">
                                                            <button type="button" class="btn btn-primary"
                                                                onclick="getToken()"
                                                                data-url="<?php echo e(route('superadmin.send.token.email')); ?>">Dapatkan
                                                                Token</button>
                                                        </div>
                                                    </div>
                                                    <!-- Display success and error messages -->
                                                    <div id="success-message" class="alert alert-success"
                                                        style="display: none;"></div>
                                                    <div id="error-message" class="alert alert-danger"
                                                        style="display: none;"></div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 text-center">
                                                <button type="submit" class="btn btn-success">Simpan</button>
                                                <button type="button" class="btn btn-danger"
                                                    onclick="cancelForm()">Batal</button>
                                            </div>
                                        </form>
                                    <?php else: ?>
                                        <p>Tidak ada setting yang sesuai.</p>
                                    <?php endif; ?>


                                    <!-- Modal Edit Mahasiswa -->

                            </div>

                        </div>
                    </div>

                    <div id="setting" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua kelompok akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="mb-3">
                                    <?php if($allsetting): ?>
                                        <form action="<?php echo e(route('superadmin.setting.update', ['id' => $allsetting->id])); ?>"
                                            method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>


                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="form-label" for="nama">Nama Website:</label>
                                                    <input type="text" name="nama"
                                                        class="form-control border-success <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="nama"
                                                        value="<?php echo e(old('nama') ?? ($allsetting->namaweb ?? '')); ?>">
                                                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="logo" class="form-label custom-file-input">Upload
                                                        Logo
                                                        Website</label>
                                                    <input
                                                        class="form-control border-success <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="logo" type="file" id="logo">
                                                    <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="start">Waktu Mulai KKN:</label>
                                                    <input type="date" name="start"
                                                        class="form-control border-success <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="start"
                                                        value="<?php echo e(old('start') ?? ($allsetting->waktu_mulai ? \Carbon\Carbon::parse($allsetting->waktu_mulai)->format('Y-m-d') : '')); ?>">
                                                    <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>


                                                <div class="form-group">
                                                    <label class="form-label" for="end">Waktu Selesai
                                                        KKN:</label>
                                                    <input type="date" name="end"
                                                        class="form-control border-success <?php $__errorArgs = ['end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="end"
                                                        value="<?php echo e(old('end') ?? ($allsetting->waktu_selesai ? \Carbon\Carbon::parse($allsetting->waktu_selesai)->format('Y-m-d') : '')); ?>">
                                                    <?php $__errorArgs = ['end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="status">Status</label>
                                                    <select name="status"
                                                        class="form-select border-success <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        data-trigger id="status">
                                                        <option value="1"
                                                            <?php echo e($allsetting->status == '1' ? 'selected' : ''); ?>>Tidak
                                                            Aktif</option>
                                                        <option value="2"
                                                            <?php echo e($allsetting->status == '2' ? 'selected' : ''); ?>>Aktif
                                                        </option>
                                                    </select>
                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                            </div>


                                            <div class="col-sm-12 text-center">
                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                                <button type="button" class="btn btn-danger">Batal</button>
                                            </div>
                                        </form>
                                    <?php else: ?>
                                        <p>Tidak ada setting yang sesuai.</p>
                                    <?php endif; ?>


                            </div>
                        </div>
                    </div>
                    <!-- Modal Edit Dosen -->
                </div>
            </div>
        </div>
        <!-- div fb Start -->
    </div>




    <!-- Footer Section Start -->

    <?php echo $__env->make('tampilan_superadmin.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function() {
            // Tambahkan kelas blink setiap 1 detik
            setInterval(function() {
                $('#aktif option:selected').toggleClass('blink');
            }, 1000);
        });
    </script>

    <script>
        function getToken() {
            const button = document.getElementById('tokenForm').querySelector('button');
            const successMessage = document.getElementById('success-message');
            const errorMessage = document.getElementById('error-message');
            const originalButtonText = button.innerText;
            const url = button.getAttribute('data-url');

            button.disabled = true;
            successMessage.style.display = 'none';
            errorMessage.style.display = 'none';

            // Simulate loading
            button.innerText = 'Loading...';

            // Make AJAX request to send email
            fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                })
                .then(response => response.json())
                .then(data => {
                    // Simulate success
                    button.innerText = 'Dapatkan Token';
                    button.disabled = false;

                    // Display success message
                    successMessage.innerText = data.message;
                    successMessage.style.display = 'block';

                    // Additional message for checking email
                    alert('Silakan cek email Anda untuk token.');
                })
                .catch(error => {
                    console.error('Error:', error);

                    // Simulate error
                    button.innerText = 'Dapatkan Token';
                    button.disabled = false;

                    // Display error message
                    errorMessage.innerText = 'Error sending email.';
                    errorMessage.style.display = 'block';
                });
        }

        function cancelForm() {
            // Implement logic to cancel or close the form here
        }
    </script>

    <script src="/admin/js/plugins/fslightbox.js" defer></script>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_superadmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gituhub\aplikasi-sistem-informasi-kkn\resources\views/SuperAdmin/setting.blade.php ENDPATH**/ ?>