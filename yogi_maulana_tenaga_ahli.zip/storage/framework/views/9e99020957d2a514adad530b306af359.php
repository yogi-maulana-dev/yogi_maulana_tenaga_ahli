<?php $__env->startSection('nilai'); ?>

    <style>
        /* Blink animation */
        @keyframes blink {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        .blink {
            animation: blink 1s infinite;
        }
    </style>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4"><?php echo e(Auth::guard('superadmin')->user()->namalengkap); ?></h4>
                                    <span> - Web Developer</span>
                                </div>
                            </div>
                            <!--<ul class="d-flex nav nav-pills mb-0 text-center profile-tab" data-toggle="slider-tab"-->
                            <!--    id="profile-pills-tab" role="tablist">-->
                            <!--    -->
                            <!--    <li class="nav-item">-->
                            <!--        <a class="nav-link active show" data-bs-toggle="tab" href="#profile-activity"-->
                            <!--            role="tab" aria-selected="false">DATA DOSEN PEMBINBING</a>-->
                            <!--    </li>-->
                            <!--    <li class="nav-item">-->
                            <!--        <a class="nav-link" data-bs-toggle="tab" href="#profile-profile" role="tab"-->
                            <!--            aria-selected="false">TAMBAH DATA DOSEN PEMBINBING</a>-->
                            <!--    </li>-->
                            <!--</ul>-->
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Kelompok
                                        <span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                            <?php $__currentLoopData = $ketuakelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($item->nokelompok); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                        dan Dosen Pembimbing
                                        <span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                            <?php $__currentLoopData = $dosenkelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($dosen->nama); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                    </h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-4">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success mt-4">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="table-responsive">
                                    <table id="example" class="stripe hover"
                                        style="width:100%; padding-top: 1em;  padding-bottom: 1em;">
                                        <thead>
                                            <tr>
                                                <th>Kelompok</th>
                                                <th>NPM</th>
                                                <th>Nama Lengkap</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $kelompoknilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($nilai->kelompoktugas); ?></td>
                                                <td><?php echo e($nilai->npm); ?></td>
                                                <td><?php echo e($nilai->mahasiswa->namalengkap); ?></td>
                                                <td>
                                                    <?php if($nilai->ketua == 1): ?>
                                                        <span
                                                            class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                                            Ketua
                                                        </span>
                                                    <?php else: ?>
                                                        <span
                                                            class="bg-soft-warning ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                                            Anggota
                                                        </span>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    
                                                    <button type="button" class="btn btn-sm btn-primary"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#nilaiMahasiswaModal<?php echo e($nilai->id); ?>">
                                                        Beri Nilai
                                                    </button>
                                                </td>
                                                </tr>

                                                <!-- Modal Edit dpl -->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>

                                            <tr>
                                                <th>Kelompok</th>
                                                <th>NPM</th>
                                                <th>Nama Lengkap</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>

                                        </tfoot>
                                    </table>
                                </div>
                            </div>

                            <!-- Modal Edit Mahasiswa -->

                        </div>

                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua dpl akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>


                    <!-- Modal Edit dpl -->
                    <div class="card">
                        <div class="card-body">
                            <p class="mb-3">
                                <?php $__currentLoopData = $kelompoknilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelompok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="modal fade" id="nilaiMahasiswaModal<?php echo e($kelompok->id); ?>" tabindex="-1"
                                        aria-labelledby="nilaiMahasiswaModalLabel<?php echo e($kelompok->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"
                                                        id="nilaiMahasiswaModalModalLabel<?php echo e($kelompok->id); ?>">Beri
                                                        Penilaian
                                                        Mahasiswa</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form
                                                    action="<?php echo e(route('superadmin.kelompok.nilai', ['id' => $kelompok->id])); ?>"
                                                    method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="modal-body">
                                                        <!-- Form untuk mengedit data kelompok -->
                                                        <div class="mb-3">
                                                            <div class="form-group">
                                                                <label for="npm">Kelompok</label>
                                                                <input type="text" class="form-control border-success"
                                                                    id="npm" name="npm"
                                                                    value="<?php echo e(old('npm', $kelompok->kelompoktugas)); ?>"
                                                                    readonly>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="npm">NPM</label>
                                                                <input type="text" class="form-control border-success"
                                                                    id="npm" name="npm"
                                                                    value="<?php echo e(old('npm', $kelompok->npm)); ?>" readonly>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="namalengkap">Nama Lengkap</label>
                                                                <input type="text" class="form-control border-success"
                                                                    id="namalengkap" name="namalengkap"
                                                                    value="<?php echo e(old('namalengkap', $kelompok->mahasiswa->namalengkap)); ?>"
                                                                    readonly>
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="nilaipembekalan">Nilai Pembekalan (5%) -
                                                                    DPL-Tim Panitia</label>
                                                                <input type="number" class="form-control border-success"
                                                                    id="nilaipembekalan" name="nilaipembekalan"
                                                                    value="<?php echo e(old('nilaipembekalan', $kelompok->nilaipembekalan)); ?>" max="100">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="nilaiperencanaan">Nilai Perencanaan (15%) -
                                                                    DPL</label>
                                                                <input type="number" class="form-control border-success"
                                                                    id="nilaiperencanaan" name="nilaiperencanaan"
                                                                    value="<?php echo e(old('nilaiperencanaan',$kelompok->nilaiperencanaan)); ?>" min="0"
                                                                    max="999" pattern="\d{3}">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="nilaipelaksanaan">Nilai Pelaksanaan (35%) - DPL
                                                                    (Memperhatikan informasi dari stakeholder dan Tim
                                                                    Pengelola)</label>
                                                                <input type="number" class="form-control border-success"
                                                                    id="nilaipelaksanaan" name="nilaipelaksanaan"
                                                                    value="<?php echo e(old('nilaipelaksanaan',$kelompok->nilaipelaksanaan)); ?>" min="0"
                                                                    max="999" pattern="\d{3}">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="kemampuaninterpersonal">Kemampuan Interpersonal
                                                                    (10%) - DPL (Memperhatikan informasi dari stakeholder
                                                                    dan Tim Pengelola)</label>
                                                                <input type="number" class="form-control border-success"
                                                                    id="kemampuaninterpersonal"
                                                                    name="kemampuaninterpersonal"
                                                                    value="<?php echo e(old('kemampuaninterpersonal',$kelompok->nilaiinterpersonal)); ?>"
                                                                    min="0" max="999" pattern="\d{3}">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="nilailaporan">Nilai Laporan Kelompok (15%) -
                                                                    DPL</label>
                                                                <input type="number" class="form-control border-success"
                                                                    id="nilailaporan" name="nilailaporan"
                                                                    value="<?php echo e(old('nilailaporan',$kelompok->nilailaporan)); ?>" min="0"
                                                                    max="999" pattern="\d{3}">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="nilaipublikasi">Publikasi (20%) - DPL dan
                                                                    LPPM</label>
                                                                <input type="number" class="form-control border-success"
                                                                    id="nilaipublikasi" name="nilaipublikasi"
                                                                    value="<?php echo e(old('nilaipublikasi',$kelompok->nilaipublikasi)); ?>" min="0"
                                                                    max="999" pattern="\d{3}">
                                                            </div>



                                                            <div class="form-group">
                                                                <label for="total">Total Nilai</label>
                                                                <input type="text" class="form-control border-success"
                                                                    id="total" name="total"
                                                                    value="<?php echo e(old('total')); ?>" readonly>
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="keterangan">Keterangan</label>
                                                                <input type="text" class="form-control border-success"
                                                                    id="keterangan" name="keterangan"
                                                                    value="<?php echo e(old('keterangan')); ?>">
                                                            </div>



                                                        </div>
                                                        <!-- Tambahkan input lainnya sesuai dengan atribut yang ingin diubah -->
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Update
                                                            Data</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        <!-- div fb Start -->
    </div>

    <!-- Footer Section Start -->

    <?php echo $__env->make('tampilan_superadmin.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        // Function to limit the input to be between 0 and 100
        function restrictInput(event) {
            var value = parseInt(event.target.value);
            if (isNaN(value) || value < 0 || value > 100) {
                event.target.value = '';
            }
        }

        // Add event listeners to each input field to restrict the input
        document.getElementById('nilaipembekalan').addEventListener('input', restrictInput);
        document.getElementById('nilaiperencanaan').addEventListener('input', restrictInput);
        document.getElementById('nilaipelaksanaan').addEventListener('input', restrictInput);
        document.getElementById('kemampuaninterpersonal').addEventListener('input', restrictInput);
        document.getElementById('nilailaporan').addEventListener('input', restrictInput);
        document.getElementById('nilaipublikasi').addEventListener('input', restrictInput);
    </script>



    <script>
        // Function to calculate the total score and determine the grade
        function calculateTotal() {
            // Get values from input fields
            var nilaiPembekalan = parseFloat(document.getElementById('nilaipembekalan').value) || 0;
            var nilaiPerencanaan = parseFloat(document.getElementById('nilaiperencanaan').value) || 0;
            var nilaiPelaksanaan = parseFloat(document.getElementById('nilaipelaksanaan').value) || 0;
            var kemampuanInterpersonal = parseFloat(document.getElementById('kemampuaninterpersonal').value) || 0;
            var nilaiLaporan = parseFloat(document.getElementById('nilailaporan').value) || 0;
            var nilaipublikasi = parseFloat(document.getElementById('nilaipublikasi').value) || 0;

            // Calculate total
            var total = (nilaiPembekalan * 0.05) + (nilaiPerencanaan * 0.15) + (nilaiPelaksanaan * 0.35) + (
                kemampuanInterpersonal * 0.10) + (nilaiLaporan * 0.15) + (nilaipublikasi * 0.20);

            // Determine the grade based on the total score
            var grade;
            if (total >= 81) {
                grade = "A";
            } else if (total >= 75) {
                grade = "B+";
            } else if (total >= 66) {
                grade = "B";
            } else if (total >= 61) {
                grade = "C+";
            } else if (total >= 55) {
                grade = "C";
            } else if (total >= 49) {
                grade = "D";
            } else {
                grade = "E";
            }

            // Display total and grade in the 'Keterangan' input field
            document.getElementById('total').value = total.toFixed(0);
            document.getElementById('keterangan').value = grade;
        }

        // Add event listeners to each input field to trigger the calculation when values change
        document.getElementById('nilaipembekalan').addEventListener('input', calculateTotal);
        document.getElementById('nilaiperencanaan').addEventListener('input', calculateTotal);
        document.getElementById('nilaipelaksanaan').addEventListener('input', calculateTotal);
        document.getElementById('kemampuaninterpersonal').addEventListener('input', calculateTotal);
        document.getElementById('nilailaporan').addEventListener('input', calculateTotal);
        document.getElementById('nilaipublikasi').addEventListener('input', calculateTotal);

        // Initial calculation when the page loads
        calculateTotal();
    </script>




    <!-- Select2 Script -->
    

    <script src="/admin/js/plugins/fslightbox.js" defer></script>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan_superadmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/kkn.uml.my.id/resources/views/SuperAdmin/nilai.blade.php ENDPATH**/ ?>