<?php

use App\Http\Controllers\Dosen\HomeController;
use App\Http\Controllers\Dosen\KelompokMahasiswaController;
use App\Http\Controllers\Dosen\LoginDosenController;
use App\Http\Controllers\Mahasiswa\DashboardContoller;
use App\Http\Controllers\Mahasiswa\ForgotPasswordController;
use App\Http\Controllers\Mahasiswa\LoginController;
use App\Http\Controllers\Mahasiswa\NilaiMahasiswaController;
use App\Http\Controllers\Mahasiswa\ProposalController;
use App\Http\Controllers\Mahasiswa\TugasController;
use App\Http\Controllers\SuperAdmin\DashboardSuperAdminController;
use App\Http\Controllers\SuperAdmin\DosenController;
use App\Http\Controllers\SuperAdmin\DplController;
use App\Http\Controllers\SuperAdmin\KelompokController;
use App\Http\Controllers\SuperAdmin\LoginSuperAdminController;
use App\Http\Controllers\SuperAdmin\LokasiController;
use App\Http\Controllers\SuperAdmin\MahasiswaController;
use App\Http\Controllers\SuperAdmin\SettingController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['guest:web', 'preventBackHistory'])->group(function () {
    Route::get('/', [LoginController::class, 'index'])->name('login');
    Route::get('/pendaftaraan', [LoginController::class, 'register'])->name('pendaftaraan');
    Route::get('/lupapassword', [LoginController::class, 'lupapassword'])->name('lupapassword');
    Route::post('/loginaction', [LoginController::class, 'loginaction'])->name('loginaction');
    Route::post('/pendaftaraan/simpan', [LoginController::class, 'store'])->name('pendaftaraan.simpan');
    Route::get('/pengumuman', [DashboardContoller::class, 'pengumuman'])->name('pengumuman');
    // Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
    Route::get('forget-password', [ForgotPasswordController::class, 'showForgetPasswordForm'])->name('forget.password.get');

    Route::post('forget-password', [ForgotPasswordController::class, 'submitForgetPasswordForm'])->name('forget.password.post');

    Route::get('reset-password/{token}', [ForgotPasswordController::class, 'showResetPasswordForm'])->name('reset.password.get');

    Route::post('reset-password', [ForgotPasswordController::class, 'submitResetPasswordForm'])->name('reset.password.post');
    Route::get('forget-password', [ForgotPasswordController::class, 'showForgetPasswordForm'])->name('forget.password.get');

    Route::post('forget-password', [ForgotPasswordController::class, 'submitForgetPasswordForm'])->name('forget.password.post');

    Route::get('reset-password/{token}', [ForgotPasswordController::class, 'showResetPasswordForm'])->name('reset.password.get');

    Route::post('reset-password', [ForgotPasswordController::class, 'submitResetPasswordForm'])->name('reset.password.post');
});

Route::middleware(['auth:web', 'preventBackHistory'])->group(function () {
    Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
    Route::get('/dashboard', [DashboardContoller::class, 'index'])->name('dashboard');
    Route::get('/pengumuman', [DashboardContoller::class, 'pengumuman'])->name('pengumuman');
    Route::get('/peringatan', [TugasController::class, 'peringatan'])->name('peringatan');
    Route::get('/tugas', [TugasController::class, 'index'])->name('tugas');
    Route::get('/nilai', [NilaiMahasiswaController::class, 'index'])->name('nilai');
    Route::post('/tugas/simpan', [TugasController::class, 'store'])->name('tugas.simpan');
    Route::get('/edit-profil', [DashboardContoller::class, 'edit'])->name('edit-profil');
    Route::put('/profil-update/{id}', [DashboardContoller::class, 'update'])->name('profil-update');
    Route::get('/update-status/{id}', [TugasController::class, 'updateStatus'])->name('updateStatus');

    Route::get('/proposal', [ProposalController::class, 'index'])->name('proposal');
    Route::post('/proposal/simpan', [ProposalController::class, 'store'])->name('proposal.simpan');
    Route::get('/update-proposal/{id}', [ProposalController::class, 'updateStatus'])->name('updateproposal');
});

Route::prefix('superadmin')
    ->name('superadmin.')
    ->group(function () {
        Route::middleware(['guest:superadmin', 'preventBackHistory'])->group(function () {
            Route::get('/', [LoginSuperAdminController::class, 'index']);

            Route::get('/login', [LoginSuperAdminController::class, 'index'])->name('login');
            Route::post('/loginaction', [LoginSuperAdminController::class, 'loginaction'])->name('loginaction');
        });

        Route::middleware(['auth:superadmin', 'preventBackHistory'])->group(function () {
            Route::post('/logout', [LoginSuperAdminController::class, 'logout'])->name('logout');
            Route::get('/dashboard', [DashboardSuperAdminController::class, 'index'])->name('dashboard');

            Route::get('/mahasiswa', [MahasiswaController::class, 'index'])->name('mahasiswa');
            Route::post('/simpan-mahasiswa', [MahasiswaController::class, 'store'])->name('simpan.mahasiswa');
            Route::get('/mahasiswa/{id}/edit', [MahasiswaController::class, 'edit'])->name('mahasiswa.edit');

            Route::delete('/mahasiswa/{id}', [MahasiswaController::class, 'destroy'])->name('mahasiswa.delete');
            Route::put('/mahasiswa/{id}', [MahasiswaController::class, 'update'])->name('mahasiswa.update');
            Route::put('/mahasiswa/reset/{id}', [MahasiswaController::class, 'reset'])->name('mahasiswa.reset');
            Route::put('/mahasiswa/aktif/{id}', [MahasiswaController::class, 'aktif'])->name('mahasiswa.aktif');
            Route::get('/cetak-pdf/{id}', [MahasiswaController::class, 'cetakPDF'])->name('cetak.pdf');

            Route::get('/dosen', [DosenController::class, 'index'])->name('dosen');
            Route::post('/simpan-dosen', [DosenController::class, 'store'])->name('simpan.dosen');
            Route::get('/dosen/{id}/edit', [DosenController::class, 'edit'])->name('dosen.edit');

            Route::delete('/dosen/{id}', [DosenController::class, 'destroy'])->name('dosen.delete');
            Route::put('/dosen/{id}', [DosenController::class, 'update'])->name('dosen.update');

            Route::get('/lokasi', [LokasiController::class, 'index'])->name('lokasi');
            Route::post('/simpan-lokasi', [LokasiController::class, 'store'])->name('simpan.lokasi');
            Route::get('/lokasi/{id}/edit', [LokasiController::class, 'edit'])->name('lokasi.edit');

            Route::delete('/lokasi/{id}', [LokasiController::class, 'destroy'])->name('lokasi.delete');
            Route::put('/lokasi/{id}', [LokasiController::class, 'update'])->name('lokasi.update');

            Route::post('/getkabupaten', [LokasiController::class, 'getkabupaten'])->name('getkabupaten');
            Route::post('/getkecamatan', [LokasiController::class, 'getkecamatan'])->name('getkecamatan');
            Route::post('/getdesa', [LokasiController::class, 'getdesa'])->name('getdesa');

            Route::get('/lokasi', [LokasiController::class, 'index'])->name('lokasi');
            Route::post('/simpan-lokasi', [LokasiController::class, 'store'])->name('simpan.lokasi');
            Route::get('/lokasi/{id}/edit', [LokasiController::class, 'edit'])->name('lokasi.edit');

            Route::delete('/lokasi/{id}', [LokasiController::class, 'destroy'])->name('lokasi.delete');
            Route::put('/lokasi/{id}', [LokasiController::class, 'update'])->name('lokasi.update');

            Route::get('get-regencies', [LokasiController::class, 'getRegencies'])->name('get.regencies');
            Route::get('get-districts', [LokasiController::class, 'getDistricts'])->name('get.districts');
            Route::get('get-villages', [LokasiController::class, 'getVillages'])->name('get.villages');

            Route::get('/kelompok', [KelompokController::class, 'index'])->name('kelompok');
            Route::get('/kelompok/search', [KelompokController::class, 'search'])->name('kelompok.search');
            Route::post('/simpan-kelompok', [KelompokController::class, 'store'])->name('simpan.kelompok');
            Route::get('/kelompok/{nokelompok}/edit', [KelompokController::class, 'edit'])->name('kelompok.edit');
            // Route::put('/kelompok/{nokelompok}', [KelompokController::class, 'update'])->name('kelompok.update');
            Route::put('/kelompok/update/{nokelompok}', [KelompokController::class, 'update'])->name('kelompok.update');

            Route::get('/cari-dosen', [KelompokController::class, 'cariDosen'])->name('cari.dosen');
            Route::get('/cari-lokasi', [KelompokController::class, 'cariLokasi'])->name('cari.lokasi');

            Route::get('/kelompok/searchedit', [KelompokController::class, 'searchedit'])->name('kelompok.searchedit');
            Route::delete('/kelompok/{nokelompok}', [KelompokController::class, 'destroy'])->name('kelompok.delete');

            Route::get('/dpl', [DplController::class, 'index'])->name('dpl');
            Route::get('/setting', [SettingController::class, 'index'])->name('setting');

            Route::put('/setting/{id}', [SettingController::class, 'update'])->name('setting.update');
            Route::put('/settingadmin/{id}', [SettingController::class, 'updateadmin'])->name('settingadmin.update');

            Route::put('/update-password', [SettingController::class, 'updatePassword'])->name('update.password');
            Route::post('/send-token-email', [SettingController::class, 'sendTokenEmail'])->name('send.token.email');

            Route::get('/kelompok/absen/{id}', [KelompokController::class, 'absen'])->name('absen');
            Route::get('/kelompok/proposal/{id}', [KelompokController::class, 'proposal'])->name('proposal');
            Route::get('/kelompok/nilai/{id}', [KelompokController::class, 'nilaiadmin'])->name('nilaiadmin');
            Route::put('/kelompok/nilai/{id}', [KelompokController::class, 'updateNilai'])->name('kelompok.nilai');

        });
    });

Route::prefix('dosen')
    ->name('dosen.')
    ->group(function () {
        Route::middleware(['guest:dosen', 'preventBackHistory'])->group(function () {
            Route::get('/', [LoginDosenController::class, 'index']);

            Route::get('/login', [LoginDosenController::class, 'index'])->name('login');
            Route::post('/loginaction', [LoginDosenController::class, 'loginaction'])->name('loginaction');
        });

        Route::middleware(['auth:dosen', 'preventBackHistory'])->group(function () {
            Route::post('/logout', [LoginDosenController::class, 'logout'])->name('logout');
            Route::get('/home', [HomeController::class, 'index'])->name('home');

            Route::get('/kelompok', [KelompokMahasiswaController::class, 'index'])->name('kelompok');

            //Update Kegiataan
            Route::get('/kelompok/kegiatan/{id}', [KelompokMahasiswaController::class, 'kegiatan'])->name('kegiatan');
            Route::get('/kelompok/absen/{id}', [KelompokMahasiswaController::class, 'absen'])->name('absen');
            Route::get('/kelompok/proposal/{id}', [KelompokMahasiswaController::class, 'proposal'])->name('proposal');
            Route::put('/kelompok/kegiatan/{id}', [KelompokMahasiswaController::class, 'updatekegiatan'])->name('kegiatanedit.update');
            // Route::get('/dosen/{id}/edit', [KelompokMahasiswaController::class, 'edit'])->name('dosen.edit');

            // Route::delete('/dosen/{id}', [KelompokMahasiswaController::class, 'destroy'])->name('dosen.delete');
            Route::put('/dosen/proposal/{id}', [KelompokMahasiswaController::class, 'updateProposal'])->name('proposal.update');
            Route::get('/edit-profil', [HomeController::class, 'edit'])->name('edit-profil');
            Route::put('/profil-update/{id}', [HomeController::class, 'update'])->name('profil-update');

            Route::post('/send-token-email', ['App\Http\Controllers\Dosen\HomeController', 'sendTokenEmail'])->name('send.token.dosen');

        });
    });
