@extends('tampilan_mhs.index')
@section('proposal')
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4">{{ Auth::guard('web')->user()->namalengkap }}</h4>

                                </div>
                            </div>
                            <ul class="d-flex nav nav-pills mb-0 text-center profile-tab" data-toggle="slider-tab"
                                id="profile-pills-tab" role="tablist">
                                {{-- <li class="nav-item">
                                        <a class="nav-link active show" data-bs-toggle="tab" href="#profile-feed"
                                            role="tab" aria-selected="false">Feed</a>
                                    </li> --}}
                                <li class="nav-item">
                                    <a class="nav-link active show" data-bs-toggle="tab" href="#profile-activity"
                                        role="tab" aria-selected="false">Kegiatan Harian</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#profile-profile" role="tab"
                                        aria-selected="false">Profile</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <p>Apa yang anda dan Kelompok ada lakukan hari ini 
                                ?</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-success">Apa yang anda dan Kelompok ada lakukan hari ini ? 
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">
                                @if ($errors->any())
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                <div class="d-flex align-items-center justify-content-between position-relative">
                             
                                    @if ($proposal->isEmpty())
    <div class="col-lg-12">
        <form action="{{ route('proposal.simpan') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="file" class="form-label">Upload Foto Kegiatan</label>
                <input class="form-control border-success @error('file') is-invalid @enderror" name="file" type="file" id="file" accept="application/pdf">
                @error('file')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group">
                <label for="exampleFormControlTextarea1" class="form-label">Keterangan</label>
                <textarea class="form-control border-success @error('keterangan') is-invalid @enderror" name="keterangan" id="exampleFormControlTextarea1" cols="30" rows="10"></textarea>
                @error('keterangan')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <button type="submit" class="btn bg-success text-white">Upload Tugas</button>
        </form>
    </div>
@else
    @foreach ($proposal as $item)
        @if ($item->status == '0')
        <div class="col-md-12">
            <div class="card mb-12">
                <div class="card-body">
                    <p>Deadline: <span id="waktuMundur"></span></p>
                </div>
            </div>
        </div>
        @elseif ($item->status == '2')
            dasd
        @endif
    @endforeach
@endif

                              
                                
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-success">Tugas yang sudah dilakukan ?
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">
                                <div
                                    class="iq-timeline0 m-0 d-flex align-items-center justify-content-between position-relative">
                                    <ul class="list-inline p-0 m-0">
                                        {{-- Periksa apakah ada data proposal --}}
                                        @if ($proposal->isNotEmpty())
                                            {{-- Tampilkan tanggal hari pertama --}}
                                            <li>
                                                <div class="timeline-dots timeline-dot1 border-primary text-primary">
                                                </div>
                                                <h6 class="float-left mb-1">Hari 1</h6>
                                                <small
                                                    class="float-right mt-1">{{ $proposal->first()->created_at->format('d F Y') }}</small>
                                                <div class="d-inline-block w-100">
                                                    <p>{{ $proposal->first()->tugas }}</p>
                                                </div>
                                            </li>

                                            {{-- Tampilkan tanggal-tanggal berikutnya --}}
                                            @foreach ($proposal as $key => $proposalx)
                                                @if ($key > 0)
                                                    <li>
                                                        <div
                                                            class="timeline-dots timeline-dot1 border-primary text-primary">
                                                        </div>
                                                        <h6 class="float-left mb-1">Hari {{ $key + 1 }}</h6>
                                                        <small
                                                            class="float-right mt-1">{{ $proposalx->created_at->addDays($key)->format('d F Y') }}</small>
                                                        <div class="d-inline-block w-100">
                                                            <p>{{ $proposalx->tugas }}</p>
                                                        </div>
                                                    </li>
                                                @endif
                                            @endforeach
                                        @else
                                            {{-- Tampilkan pesan jika tidak ada data proposal --}}
                                            <li>Data tidak tersedia.</li>
                                        @endif
                                    </ul>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua kelompok akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                  
                    </div>
                </div>
            </div>

        </div>

    </div>
    <script>
        var statusUpdated = false; // Variabel untuk menandai apakah status sudah diupdate
    
        @foreach ($proposal as $proposalx)
            var proposalStatus = "{{ $proposalx->status }}";
    
            if (proposalStatus === '0') {
                // Ambil waktu tugas dibuat
                var created_at = new Date("{{ $proposalx->created_at }}");
    
                // Set waktu target (23:59:00)
                // var deadline = new Date("2024-04-17T19:59:00"); // Format tanggal: tahun-bulan-tanggalTjam:menit:detik
                var deadline = new Date(created_at);
                deadline.setHours(23);
                deadline.setMinutes(59);
                deadline.setSeconds(30);

                // Update status dan tampilkan waktu mundur menggunakan JavaScript
                var interval = setInterval(function() {
                    var now = new Date(); // Format tanggal: tahun-bulan-tanggalTjam:menit:detik
                    var difference = deadline - now;
    
                    if (difference <= 0 && !statusUpdated) {
                        // Waktu habis, update status dan tampilkan pesan
                        clearInterval(interval);
                        $.ajax({
                            url: "{{ route('updateproposal', $proposalx->id) }}",
                            type: "GET",
                          
                            success: function(response) {
                                console.log(response.message);
                                // Tidak lakukan redirect jika sudah diupdate
                            },
                            error: function(xhr, status, error) {
                                console.error(xhr.responseText);
                            }
                        });
                    } else {
                        // Hitung sisa waktu mundur
                        var remainingTime = new Date(difference);
    
                        // Ambil jam, menit, dan detik dari sisa waktu mundur
                        var hours = remainingTime.getUTCHours();
                        var minutes = remainingTime.getUTCMinutes();
                        var seconds = remainingTime.getUTCSeconds();
    
                        // Format output waktu mundur
                        var displayTime = hours + " jam " + minutes + " menit " + seconds + " detik ";
                        $("#waktuMundur").text(displayTime);
                    }
                }, 1000);
            }
        @endforeach
    </script>
    
    <!-- Footer Section Start -->
    @include('tampilan_mhs.javascript')
    <!-- Footer Section End -->
    </main>
@endsection
