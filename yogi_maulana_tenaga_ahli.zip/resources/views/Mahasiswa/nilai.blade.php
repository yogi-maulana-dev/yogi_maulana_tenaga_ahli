@extends('tampilan_mhs.index')
@section('nilai')

<style>
    .table {
   width: 40%;
}
</style>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4">{{ Auth::guard('web')->user()->namalengkap }}</h4>

                                </div>
                            </div>
                            <ul class="d-flex nav nav-pills mb-0 text-center profile-tab" data-toggle="slider-tab"
                                id="profile-pills-tab" role="tablist">
                                {{-- <li class="nav-item">
                                        <a class="nav-link active show" data-bs-toggle="tab" href="#profile-feed"
                                            role="tab" aria-selected="false">Feed</a>
                                    </li> --}}
                                <li class="nav-item">
                                    <a class="nav-link active show" data-bs-toggle="tab" href="#profile-activity"
                                        role="tab" aria-selected="false">Nilai Mahasiswa</a>
                                </li>
                                {{-- <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#profile-profile" role="tab"
                                        aria-selected="false">Profile</a>
                                </li> --}}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Kelompok NPM</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Nilai akan muncul setelah kegiatan telah berakhir.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">KKN KELOMPOK <span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                        {{$allnilai->kelompoktugas}} </span> Tahun
                                        <span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                            {{\Carbon\Carbon::parse($allsetting->waktu_mulai)->format('Y')}}
                                        </span></h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <tr>
                                        <td>Nomor Pokok Mahasiswa</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->npm}}</span></td>
                                    </tr>
                                    <tr>
                                        <td>Nilai Pembekalan</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->nilaipembekalan}}</span></td>
                                    </tr>
                                    <tr>
                                        <td>Nilai Perencanaan</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->nilaiperencanaan}}</span></td>
                                    </tr>
                                    <tr>
                                        <td>Nilai Pelaksanaan</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->nilaipelaksanaan}}</span></td>
                                    </tr>
                                    <tr>
                                        <td>Nilai Interpersonal</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->nilaiinterpersonal}}</span></td>
                                    </tr>
                                    <tr>
                                        <td>Nilai Laporan</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->nilailaporan}}</span></td>
                                    </tr>
                                    <tr>
                                        <td>Nilai Publikasi</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->nilaipublikasi}}</span></td>
                                    </tr>
                                    <tr>
                                        <td>Nilai Total</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->total}}</span></td>
                                    </tr>
                                    <tr>
                                        <td>Keterangan</td>
                                        <td><span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">{{$allnilai->keterangan}}</span></td>
                                    </tr>
                                </table>
                            </div>
                            
                        </div>

                    </div>

                    {{-- <div id="profile-profile" class="tab-pane fade">
                       
                    </div> --}}
                </div>
            </div>

        </div>

    </div>

    <!-- Footer Section Start -->
    @include('tampilan_mhs.javascript')
    <!-- Footer Section End -->
    </main>
@endsection
