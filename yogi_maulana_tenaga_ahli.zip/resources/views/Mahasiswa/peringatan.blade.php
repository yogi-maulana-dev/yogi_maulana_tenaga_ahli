@extends('tampilan_mhs.index')
@section('peringatan')
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title text-warning">Peringatann !!!
                                    </h4>
                                </div>
                            </div>

                            <div class="card-body">

                                @if (session('warning'))
                                    <div class="alert alert-warning mt-4">
                                        {{ session('warning') }}
                                    </div>
                                @endif
                                @if (session('error'))
                                    <div class="alert alert-warning mt-4">
                                        {{ session('error') }}
                                    </div>
                                @endif

                            </div>


                        </div>
                    </div>
                </div>


            </div>
        </div>

    </div>

    </div>

    <!-- Footer Section Start -->
    @include('tampilan_mhs.javascript')
    <!-- Footer Section End -->
    </main>
@endsection
