{{-- Header --}}
# Selamat Datang, Admin!

{{-- Content --}}

Anda telah menerima token baru untuk menggati password. Silakan gunakan token berikut untuk login:
<div style="border: 1px solid #ddd; padding: 10px; background-color: #f9f9f9;">
    {{ $token }}
</div>
Jangan berikan token ini kepada siapapun. Terima kasih!<br>


{{-- Footer --}}
Terima kasih,<br>



@push('css')
    <style>
        /* Tambahkan gaya CSS sesuai kebutuhan */
        body {
            font-family: 'Arial', sans-serif;
        }

        h1 {
            color: #333;
        }

        /* Tambahkan gaya CSS lainnya */
    </style>
@endpush
