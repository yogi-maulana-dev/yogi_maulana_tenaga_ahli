@extends('tampilan_dosen.index')
@section('kegiatan')

    <style>
        .btn-group .btn {
            margin-right: 5px;
        }

        .modal-body {
            background-color: #e8e8e8;
            padding: 20px;
        }

        .kartu {
            width: 800px;
            margin: 0 auto;
            margin-top: 5px;
            box-shadow: 0 0.25rem 0.75rem rgba(0, 0, 0, .03);
            transition: all .3s;
        }

        .foto {
            padding: 20px;
        }

        .modal-body tbody {
            font-size: 20px;
            font-weight: 300;
        }

        .biodata {
            margin-top: 30px;
        }
    </style>

    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <!-- Add other images if necessary -->
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4">{{ Auth::guard('dosen')->user()->namalengkap }}</h4>
                                    <span> - Super Admin</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">
                    <div id="profile-activity" class="tab-pane fade active show">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Data Kegiatan Kelompok
                                        <span class="bg-soft-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">
                                            @foreach ($kelompok as $item)
                                                {{ $item->nokelompok }}
                                            @endforeach
                                        </span>
                                    </h4>
                                </div>
                            </div>
                            <div class="card-body">
                                @if ($errors->any())
                                    <div class="alert alert-danger mt-4">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif

                                @if (session('success'))
                                    <div class="alert alert-success mt-4">
                                        {{ session('success') }}
                                    </div>
                                @endif
                                @if (session('error'))
                                    <div class="alert alert-warning mt-4">
                                        {{ session('error') }}
                                    </div>
                                @endif

                                <div class="table-responsive">
                                    <table id="example" class="stripe hover"
                                        style="width:100%; padding-top: 1em; padding-bottom: 1em;">
                                        <thead>
                                            <tr>
                                                <th>Foto</th>
                                                <th>Kelompok</th>
                                                <th>Waktu Mengirim</th>
                                                <th>Periksa</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($allkegiatan as $kegiatan)
                                                <tr>
                                                    <td style="max-width: 100px;">
                                                        <a data-fslightbox="gallery"
                                                            href="{{ url($kegiatan->fotokegiatan) }}">
                                                            <img src="{{ url($kegiatan->fotokegiatan) }}"
                                                                class="img-fluid bg-soft-primary rounded w-100 h-100"
                                                                alt="profile-image" loading="lazy">
                                                        </a>
                                                    </td>
                                                    <td>{{ $kegiatan->kelompoktugas }}</td>
                                                    <td>{{ \Carbon\Carbon::parse($kegiatan->created_at)->format('d F Y H:i:s') }}
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-primary"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#editKegiatanModal{{ $kegiatan->id }}">
                                                            Edit
                                                        </button>
                                                    </td>
                                                    <td>
                                                        @if ($kegiatan->status == '2')
                                                            <h5 class="text-success">Sudah Diperiksa</h5>
                                                        @else
                                                            <h5 class="text-warning">Belum Diperiksa</h5>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Foto</th>
                                                <th>Kelompok</th>
                                                <th>Waktu Mengirim</th>
                                                <th>Status</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="profile-profile" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">
                                    <div class="mt-3">
                                        <p class="d-inline-block pl-3">- Perhatikan untuk ketua kelompok akan dipilih dengan
                                            mengisi form data diri lalu diberikan kepada admin, membawa bukti pembayaran.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            <!-- Modal Edit Kegiatan -->
            @foreach ($allkegiatan as $kegiatanedit)
                <div class="modal fade" id="editKegiatanModal{{ $kegiatanedit->id }}" tabindex="-1"
                    aria-labelledby="editKegiatanModalLabel{{ $kegiatanedit->id }}" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editKegiatanModalLabel{{ $kegiatanedit->id }}">Edit Kegiatan
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="editForm{{ $kegiatanedit->id }}" action="{{ route('dosen.kegiatanedit.update', ['id' => $kegiatanedit->id]) }}" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <div class="mb-3">
                                        <label for="kelompoktugas" class="form-label">Kelompok Tugas</label>
                                        <input type="text" class="form-control" id="kelompoktugas" name="kelompoktugas"
                                            value="{{ $kegiatanedit->kelompoktugas }}">
                                    </div>

                                    <div class="form-group">
                                         <label for="kelompoktugas" class="form-label">Foto Kegiatan</label>
                                        <div class="grid grid-cols-3 gap-4">
                                            <a data-fslightbox="gallery" href="{{ url($kegiatanedit->fotokegiatan) }}">
                                                <img src="{{ url($kegiatanedit->fotokegiatan) }}"
                                                    class="img-fluid bg-soft-primary rounded"
                                                    style="width: 200px; height:200px; object-fit:cover;"
                                                    alt="profile-image" loading="lazy">
                                            </a>
                                        </div>
                                    </div>

                                        <div class="form-group">
                                                   <label for="kelompoktugas" class="form-label">Ubah Status Kegiatan</label>
                                        <div class="grid grid-cols-3 gap-4">
                                            <select name="status" 
                                                style="color: {{ $kegiatanedit->status == '2' ? 'green' : ($kegiatanedit->status == '0' ? 'red' : 'black') }}">
                                                <option value="">==Silakan Pilih Status==</option>
                                                <option value="2" {{ $kegiatanedit->status == '2' ? 'selected' : '' }}>Sudah Periksa</option>
                                                <option value="0" {{ $kegiatanedit->status == '0' ? 'selected' : '' }}>Belum Diperikasa</option>
                                            </select>
                                        </div>
                                    </div>
                                    

                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary save-btn"
                                    data-form-id="{{ $kegiatanedit->id }}">Simpan Status Kegiatan</button>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach

        </div>
    </div>

    @include('tampilan_dosen.javascript')

    <script>
        $(document).ready(function() {
            $('.save-btn').click(function() {
                var formId = $(this).data('form-id');
                $('#editForm' + formId).submit();
            });
        });
    </script>

    <script src="/admin/js/plugins/fslightbox.js" defer></script>

    </main>
@endsection
