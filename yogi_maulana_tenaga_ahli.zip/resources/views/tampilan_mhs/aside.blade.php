<aside class="sidebar sidebar-base" id="first-tour" data-toggle="main-sidebar" data-sidebar="responsive">
        <div class="sidebar-header d-flex align-items-center justify-content-start">
            <a href="{{ route('dashboard') }}" class="navbar-brand">
                <!--Logo start-->
                <div class="logo-main">
                <div class="logo-normal">
                    @php
                    $allsetting = \App\Models\Setting::first();
                    @endphp
                    <img src="{{ url($allsetting->gambar) }}" alt="Logo Normal" class="img-fluid">
                </div>
              <div class="logo-mini">
                    <img src="{{ url($allsetting->gambar) }}" alt="Logo Mini" class="img-fluid">
                </div> 
            </div>
                <!--logo End-->
                <!--<h4 class="logo-title" data-setting="app_name">SKKN</h4>-->
            </a>
            <div class="sidebar-toggle" data-toggle="sidebar" data-active="true">
                <i class="icon">
                    <svg class="icon-20" width="20" height="20" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M4.25 12.2744L19.25 12.2744" stroke="currentColor" stroke-width="1.5"
                            stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M10.2998 18.2988L4.2498 12.2748L10.2998 6.24976" stroke="currentColor"
                            stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                </i>
            </div>
        </div>
        <div class="sidebar-body pt-0 data-scrollbar">
            <div class="sidebar-list">
                <!-- Sidebar Menu Start -->
                <ul class="navbar-nav iq-main-menu" id="sidebar-menu">
                    <li class="nav-item static-item">
                        <a class="nav-link static-item disabled text-start" href="#" tabindex="-1">
                            <span class="default-icon">Home</span>
                            <span class="mini-icon" data-bs-toggle="tooltip" title="Home"
                                data-bs-placement="right">-</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                        <a class="nav-link" aria-current="page" href="{{ route('dashboard') }}">
                            <i class="icon" data-bs-toggle="tooltip" title="Dashboard" data-bs-placement="right">
                                <svg width="20" class="icon-20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <!-- Icon SVG -->
                                </svg>
                            </i>
                            <span class="item-name">Dashboard</span>
                        </a>
                    </li>
                    
                    <li class="nav-item {{ request()->routeIs('tugas') ? 'active' : '' }}">
                        <a class="nav-link" aria-current="page" href="{{ route('tugas') }}">
                            <i class="icon" data-bs-toggle="tooltip" title="Dashboard" data-bs-placement="right">
                                <svg width="20" class="icon-20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <!-- Icon SVG -->
                                </svg>
                            </i>
                            <span class="item-name">Kegiatan</span>
                        </a>
                    </li>
                    


                    <li>
                        <hr class="hr-horizontal" />
                    </li>

                   


                    <!-- Sidebar Menu End -->
            </div>
        </div>
        <div class="sidebar-footer"></div>
    </aside>