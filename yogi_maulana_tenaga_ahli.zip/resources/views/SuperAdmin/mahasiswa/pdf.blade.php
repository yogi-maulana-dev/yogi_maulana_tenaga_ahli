<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulir Biodata Mahasiswa KKN</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            margin: 5px auto;
            position: relative;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border-top: none;
            border-bottom: none;
            font-size: 14px;
            
            /* border: 1px solid black; */
        }

        th {
            background-color: #f2f2f2;
            width: 30%;
        }

        .photo {
            width: 100%;
        }

        .table1 {
            border-collapse: collapse;
            width: 100%;
            text-align: center;
            border: none;
        }

        h1,
        h2,
        h3 {
            margin-bottom: 10px;
        }


        .rangkasurat {
            width: 100%;
            background-color: #fff;
            height: auto;
            padding: 10px;
        }

        .table1 {
            border-bottom: 2px solid #000;
        }

        .tengah {
            text-align: center;
            line-height: 15px;
        }

        .ttd {
            float: right;
            width: 250px;
            background-position: center;
            background-size: contain;
        }
    </style>
</head>

<body>
    <div class="container">

        <div class="rangkasurat">
            <table class="table1" width="100%">
                <tr>
                    <td>  <img src="{{ url('uploads/LOGO-UML-PANJANG-3-200x41.png') }}" width="140px"> </td>
                    <td class="tengah">
                        <h3  style="color: green;">Universitas Muhammadiyah Lampung</h3>
                        <b style="font-size: 14px;">
                            Jl. ZA. Pagar Alam, Labuhan Ratu, Kec. Kedaton, Bandar Lampung 35132, Telp . (0811) 781 1414 </b>
                    </td>
                </tr>
            </table>
        </div>


      <table>
    <tr>
        <th style="border-bottom: 1px solid black;">Nomor Pokok Mahasiswa</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->npm }}</td>
        <td rowspan="9" align="center"><img class="photo" src="{{ $mahasiswa->gambar }}" width="150" height="200" alt="Foto Biodata"></td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Nama Lengkap</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->namalengkap }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Email</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->email }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Jenis Kelamin</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->jk }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Tempat, Tanggal Lahir</th>
        <td style="border-bottom: 1px solid black;"> {{ $mahasiswa->tempat }}, {{ \Carbon\Carbon::parse($mahasiswa->tgllahir)->format('d - m - Y') }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">No. Telepon / HP</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->nohp }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Fakultas</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->fakultas }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Jurusan</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->jurusan }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Alamat</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->alamat }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Size Ukuran Baju</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->sizebaju }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Kelas</th>
        <td style="border-bottom: 1px solid black;">{{ $mahasiswa->kelas }}</td>
    </tr>
    <tr>
        <th style="border-bottom: 1px solid black;">Bukti Pembayaran</th>
        <td colspan="2"> <img src="{{ $mahasiswa->gambarbayar }}" alt="Bukti Pembayaran" width="380" height="200"></td>
    </tr>
</table>



        <table width="450" align="right" class="ttd">
            <tr>
                <td width="100px" style="padding:20px;" align="center">
                    <strong>Fungky marian,M.Pd</strong>
                    <br><br><br><br>
                    <br><br>
                    <strong><u>TTD</u><br></strong><small></small>
                </td>
            </tr>
        </table>

    </div>
</body>

</html>
