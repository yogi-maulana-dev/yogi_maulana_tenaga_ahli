@extends('tampilan_superadmin.index')
@section('setting')
    <style>
        /* Blink animation */
        @keyframes blink {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        .blink {
            animation: blink 1s infinite;
        }
    </style>
    <div class="content-inner container-fluid pb-0" id="page_layout">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="profile-img position-relative me-3 mb-3 mb-lg-0 profile-logo profile-logo1">
                                    <img src="/admin/images/avatars/01.png" alt="User-Profile"
                                        class="theme-color-default-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_1.png" alt="User-Profile"
                                        class="theme-color-purple-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_2.png" alt="User-Profile"
                                        class="theme-color-blue-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_4.png" alt="User-Profile"
                                        class="theme-color-green-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_5.png" alt="User-Profile"
                                        class="theme-color-yellow-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                    <img src="/admin/images/avatars/avtar_3.png" alt="User-Profile"
                                        class="theme-color-pink-img img-fluid rounded-pill avatar-100" loading="lazy" />
                                </div>
                                <div class="d-flex flex-wrap align-items-center mb-3 mb-sm-0">
                                    <h4 class="me-2 h4">{{ Auth::guard('superadmin')->user()->namalengkap }}</h4>
                                    <span> - SuperAdmin</span>
                                </div>
                            </div>
                            <ul class="d-flex nav nav-pills mb-0 text-center profile-tab" data-toggle="slider-tab"
                                id="profile-pills-tab" role="tablist">
                                {{-- <li class="nav-item">
                                        <a class="nav-link active show" data-bs-toggle="tab" href="#profile-feed"
                                            role="tab" aria-selected="false">Feed</a>
                                    </li> --}}
                                <li class="nav-item">
                                    <a class="nav-link active show" data-bs-toggle="tab" href="#profile-activity"
                                        role="tab" aria-selected="false">Profil Admin</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#setting" role="tab"
                                        aria-selected="false">Setting Website</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="profile-content tab-content iq-tab-fade-up">

                    <div id="profile-activity" class="tab-pane fade active show">


                        <div class="card">
                            <div class="card-body">

                                @if ($errors->any())
                                    <div class="alert alert-danger mt-4">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif

                                @if (session('success'))
                                    <div class="alert alert-success mt-4">
                                        {{ session('success') }}
                                    </div>
                                @endif
                                @if (session('error'))
                                    <div class="alert alert-warning mt-4">
                                        {{ session('error') }}
                                    </div>
                                @endif

                                <p class="mb-3">
                                    @if ($allsettingadmin)
                                        <form
                                            action="{{ route('superadmin.settingadmin.update', ['id' => $allsettingadmin->id]) }}"
                                            method="POST" enctype="multipart/form-data" id="tokenForm">
                                            @csrf
                                            @method('PUT')

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="form-label" for="namalengkap">Nama Lengkap:</label>
                                                    <input type="text" name="namalengkap"
                                                        class="form-control border-success @error('namalengkap') is-invalid @enderror"
                                                        id="namalengkap"
                                                        value="{{ old('namalengkap') ?? ($allsettingadmin->namalengkap ?? '') }}">
                                                    @error('namalengkap')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="email">Email (Email Wajib Aktif):</label>
                                                    <input type="email" name="email"
                                                        class="form-control border-success @error('email') is-invalid @enderror"
                                                        id="email"
                                                        value="{{ old('email') ?? ($allsettingadmin->email ?? '') }}">
                                                    @error('email')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="nohp">Nomor HandPhone:</label>
                                                    <input type="text" name="nohp"
                                                        class="form-control border-success @error('nohp') is-invalid @enderror"
                                                        id="nohp"
                                                        value="{{ old('nohp') ?? ($allsettingadmin->nohp ?? '') }}">
                                                    @error('nohp')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="password">Password Ganti:</label>
                                                    <input type="text" name="password"
                                                        class="form-control border-success @error('password') is-invalid @enderror"
                                                        id="password" value="{{ old('password') }}">
                                                    @error('password')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <label for="token" class="form-label">Token</label>
                                                    <div class="input-group">
                                                        <input type="text" name="token" id="token"
                                                            class="form-control border-success">
                                                        <div class="input-group-append">
                                                            <button type="button" class="btn btn-primary"
                                                                onclick="getToken()"
                                                                data-url="{{ route('superadmin.send.token.email') }}">Dapatkan
                                                                Token</button>
                                                        </div>
                                                    </div>
                                                    <!-- Display success and error messages -->
                                                    <div id="success-message" class="alert alert-success"
                                                        style="display: none;"></div>
                                                    <div id="error-message" class="alert alert-danger"
                                                        style="display: none;"></div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 text-center">
                                                <button type="submit" class="btn btn-success">Simpan</button>
                                                <button type="button" class="btn btn-danger"
                                                    onclick="cancelForm()">Batal</button>
                                            </div>
                                        </form>
                                    @else
                                        <p>Tidak ada setting yang sesuai.</p>
                                    @endif


                                    <!-- Modal Edit Mahasiswa -->

                            </div>

                        </div>
                    </div>

                    <div id="setting" class="tab-pane fade">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title">Pengumuman</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="text-left">

                                    <div class="mt-3">

                                        <p class="d-inline-block pl-3"> - Perhatikan untuk ketua kelompok akan dipilih
                                            dengan mengisi form data diri lalu diberikan kepada admin, membawa bukti
                                            pembayaran.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="mb-3">
                                    @if ($allsetting)
                                        <form action="{{ route('superadmin.setting.update', ['id' => $allsetting->id]) }}"
                                            method="POST" enctype="multipart/form-data">
                                            @csrf
                                            @method('PUT')


                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="form-label" for="nama">Nama Website:</label>
                                                    <input type="text" name="nama"
                                                        class="form-control border-success @error('nama') is-invalid @enderror"
                                                        id="nama"
                                                        value="{{ old('nama') ?? ($allsetting->namaweb ?? '') }}">
                                                    @error('nama')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <div class="grid grid-cols-3 gap-4">
                                                        <a data-fslightbox="gallery"
                                                            href="{{ url($allsetting->gambar) }}">
                                                            <img src="{{ url($allsetting->gambar) }}"
                                                                class="img-fluid bg-soft-primary rounded w-100 h-100"
                                                                alt="profile-image" loading="lazy">
                                                        </a>
                                                    </div>
                                                    <label for="logo" class="form-label custom-file-input">Upload
                                                        Logo
                                                        Website Ukurannya (200 x 41)</label>
                                                    <input
                                                        class="form-control border-success @error('logo') is-invalid @enderror"
                                                        name="logo" type="file" id="logo">
                                                    @error('logo')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="start">Waktu Mulai KKN:</label>
                                                    <input type="date" name="start"
                                                        class="form-control border-success @error('start') is-invalid @enderror"
                                                        id="start"
                                                        value="{{ old('start') ?? ($allsetting->waktu_mulai ? \Carbon\Carbon::parse($allsetting->waktu_mulai)->format('Y-m-d') : '') }}">
                                                    @error('start')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>


                                                <div class="form-group">
                                                    <label class="form-label" for="end">Waktu Selesai
                                                        KKN:</label>
                                                    <input type="date" name="end"
                                                        class="form-control border-success @error('end') is-invalid @enderror"
                                                        id="end"
                                                        value="{{ old('end') ?? ($allsetting->waktu_selesai ? \Carbon\Carbon::parse($allsetting->waktu_selesai)->format('Y-m-d') : '') }}">
                                                    @error('end')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <label class="form-label" for="status">Status</label>
                                                    <select name="status"
                                                        class="form-select border-success @error('status') is-invalid @enderror"
                                                        data-trigger id="status">
                                                        <option value="1"
                                                            {{ $allsetting->status == '1' ? 'selected' : '' }}>Tidak
                                                            Aktif</option>
                                                        <option value="2"
                                                            {{ $allsetting->status == '2' ? 'selected' : '' }}>Aktif
                                                        </option>
                                                    </select>
                                                    @error('status')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>

                                            </div>


                                            <div class="col-sm-12 text-center">
                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                                <button type="button" class="btn btn-danger">Batal</button>
                                            </div>
                                        </form>
                                    @else
                                        <p>Tidak ada setting yang sesuai.</p>
                                    @endif


                            </div>
                        </div>
                    </div>
                    <!-- Modal Edit Dosen -->
                </div>
            </div>
        </div>
        <!-- div fb Start -->
    </div>




    <!-- Footer Section Start -->

    @include('tampilan_superadmin.javascript')

    <script>
        $(document).ready(function() {
            // Tambahkan kelas blink setiap 1 detik
            setInterval(function() {
                $('#aktif option:selected').toggleClass('blink');
            }, 1000);
        });
    </script>

    <script>
        function getToken() {
            const button = document.getElementById('tokenForm').querySelector('button');
            const successMessage = document.getElementById('success-message');
            const errorMessage = document.getElementById('error-message');
            const originalButtonText = button.innerText;
            const url = button.getAttribute('data-url');

            button.disabled = true;
            successMessage.style.display = 'none';
            errorMessage.style.display = 'none';

            // Simulate loading
            button.innerText = 'Loading...';

            // Make AJAX request to send email
            fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                })
                .then(response => response.json())
                .then(data => {
                    // Simulate success
                    button.innerText = 'Dapatkan Token';
                    button.disabled = false;

                    // Display success message
                    successMessage.innerText = data.message;
                    successMessage.style.display = 'block';

                    // Additional message for checking email
                    alert('Silakan cek email Anda untuk token.');
                })
                .catch(error => {
                    console.error('Error:', error);

                    // Simulate error
                    button.innerText = 'Dapatkan Token';
                    button.disabled = false;

                    // Display error message
                    errorMessage.innerText = 'Error sending email.';
                    errorMessage.style.display = 'block';
                });
        }

        function cancelForm() {
            // Implement logic to cancel or close the form here
        }
    </script>

    <script src="/admin/js/plugins/fslightbox.js" defer></script>

    </main>
@endsection
