<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Models\Setting;
use App\Models\SuperAdmin;
use Illuminate\Support\Str;
use App\Mail\AdminTokenMail;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
       $allsetting = Setting::first();
       $allsettingadmin = SuperAdmin::where('id', Auth::guard('superadmin')->user()->id)->first();
        return view('SuperAdmin.setting', compact('allsetting','allsettingadmin'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Temukan data setting berdasarkan ID yang diberikan
        $allsetting = Setting::findOrFail($id);
    
        // Validasi input data
        $validatedData = $request->validate([
            'nama' => 'required|string',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Logo bersifat opsional
            'start' => 'required|date',
            'end' => 'required|date',
            'status' => 'required|in:1,2',
        ]);
    
        // Persiapkan data untuk pembaruan
        $updateData = [
            'namaweb' => $validatedData['nama'],
            'waktu_mulai' => $validatedData['start'],
            'waktu_selesai' => $validatedData['end'],
            'status' => $validatedData['status'],
        ];
    
        // Periksa apakah ada file logo yang diunggah
        if ($request->hasFile('logo')) {
            // Validasi logo baru
          
        
            // Hapus logo lama jika ada
            if ($allsetting->gambar && file_exists(public_path($allsetting->gambar))) {
                unlink(public_path($allsetting->gambar));
            }
            
            // Upload logo baru
            $logo = $request->file('logo');
           
            $nama_logo = $id . '_' . time() . '.' . $logo->getClientOriginalExtension();
            $lokasi = public_path('uploads/website/gambar');
            $logo->move($lokasi, $nama_logo);
            
            // Set gambar baru pada model Mahasiswa
            $updateData['gambar'] = 'uploads/website/gambar/' . $nama_logo;
        }
    
        // Lakukan pembaruan data pada setting
        $allsetting->update($updateData);
    
        // Redirect kembali ke halaman setting dengan pesan sukses
        return redirect()->route('superadmin.setting')->with('success', 'Data setting berhasil diupdate!');
    }



    public function updateadmin(Request $request, $id)
{
    // Validasi data yang dikirimkan
    $user = Auth::guard('superadmin')->user();
 
    // Validasi token
    $token = $request->input('token');
    if ($token !== $user->token) {
        return redirect()->back()->withErrors(['token' => 'Token tidak valid']);
    }

    // Validasi input data
    $validatedData = $request->validate([
        'namalengkap' => 'string',
        'email' => 'email',
        'password' => 'nullable|min:8',
        'nohp' => 'nullable|string|max:15',
    ]);

    // Prepare update data
    $updateData = [
        'namalengkap' => $validatedData['namalengkap'],
        'email' => $validatedData['email'],
        'nohp' => $validatedData['nohp'],
    ];

    // Update password if provided
    if ($request->filled('password')) {
        $updateData['password'] = Hash::make($validatedData['password']);
    }

    // Update the user's data
    $user->update($updateData);

    // Clear the token
    $user->update(['token' => null]);

    // Redirect back to the setting page with a success message
    return redirect()->route('superadmin.setting')->with('success', 'Data setting Admin berhasil diupdate!');
}



    /**
     * Remove the specified resource from storage.
     */
    public function sendTokenEmail(Request $request)
    {
        $user = Auth::guard('superadmin')->user();
    
        // Generate token
        $token = Str::random(6);
    
        // Save the token to the admin model
        $user->update(['token' => $token]);
    
        // Save the admin model
        $user->save();
    
        // Send the token via email
        Mail::to($user->email)->send(new AdminTokenMail($token));
    
        return response()->json(['message' => 'Email berhasil dikirim.']);
    }
    
}
