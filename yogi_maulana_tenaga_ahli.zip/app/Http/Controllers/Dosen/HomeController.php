<?php

namespace App\Http\Controllers\Dosen;

use App\Models\Dosen;
use App\Models\Prodi;
use App\Models\Falkultas;
use Illuminate\Support\Str;
use App\Mail\AdminTokenMail;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        return view('Dosen.home', ['judul' => 'Halaman Home Dosen']);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit()
    {
        $prodix = Prodi::all();
        $fakultasx = Falkultas::all();

        return view('Dosen.profil-edit',compact('prodix','fakultasx'), ['judul' => 'Edit Data Profil']);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
{
    try {
        // Validasi data yang masuk
        $validationRules = [
            'namalengkap' => 'required|string',
            'email' => 'required|email|unique:dosen,email,' . Auth::guard('dosen')->user()->id,
            'nohp' => 'required|numeric',
            'password' => 'nullable|string|min:6', // Password bisa nullable dan minimal 6 karakter jika diisi
            'jk' => 'required|string',
            'alamat' => 'required|string',
            'jurusan' => 'required|string',
        ];

        $validator = Validator::make($request->all(), $validationRules);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $dosen = Auth::guard('dosen')->user(); // Menggunakan guard 'dosen' karena terkait dosen

        // Update model dosen dengan data dari form
        $dosen->update([
            'nama' => $request->input('namalengkap'),
            'email' => $request->input('email'),
            'nohp' => $request->input('nohp'),
            'jk' => $request->input('jk'),
            'alamat' => $request->input('alamat'),
            'jurusan' => $request->input('jurusan'),
        ]);

        // Update password jika diisi
        if ($request->filled('password')) {
            $dosen->password = bcrypt($request->input('password'));
        }

        // Simpan perubahan pada model dosen
        $dosen->save();

        return redirect()->route('dashboard')->with('success', 'Data berhasil diperbarui.');
    } catch (\Exception $e) {
        return redirect()
            ->back()
            ->with('error', 'Terjadi kesalahan: ' . $e->getMessage())
            ->withInput();
    }
}

public function sendTokenEmail(Request $request,$id)
{
    $user = Dosen::findOrFail($id);

    // Generate token
    $token = Str::random(6);

    // Save the token to the admin model
    $user->update(['token' => $token]);

    // Save the admin model
    $user->save();

    // Send the token via email
    Mail::to($user->email)->send(new AdminTokenMail($token));

    return response()->json(['message' => 'Email berhasil dikirim.']);
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
