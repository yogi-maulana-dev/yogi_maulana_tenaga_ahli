<?php

namespace App\Http\Controllers\Dosen;

use DateTime;
use DatePeriod;
use DateInterval;
use App\Models\Dosen;
use App\Models\TabungTugas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class AbsenKegiatanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        // Tanggal awal dan akhir absen
      $tanggal_awal = '2024-07-24';
        $tanggal_akhir = '2024-09-07';

        // Ambil tanggal saat ini
        $tanggal_sekarang = now()->toDateString();

        // Jika tanggal akhir absen melebihi tanggal saat ini, maka atur tanggal akhir menjadi tanggal saat ini
        if ($tanggal_akhir > $tanggal_sekarang) {
            $tanggal_akhir = $tanggal_sekarang;
        }


        $userId = Auth::guard('dosen')->id();
        $user = Dosen::find($userId);

        $kehadiran = DB::table('kelompok')
            ->where('dosen', $user->nip)
            ->where('ketua', '1')
            ->get();

        // Hitung total hari absen
        // $jumlah_hari = now()->diffInDays($tanggal_awal) + 1;
        return $kehadiran;

        // return view('Dosen.absen', compact('kehadiran', 'jumlah_hari'));
    }

    public function absen(Request $request, $id)
    {
        $tanggal_awal = '2024-07-24';
        $tanggal_akhir = '2024-09-07';

        $kelompok = TabungTugas::where('kelompoktugas', $id)->get();

        $dates = [];
        $total_hadir = 0;
        $total_alpa = 0;

        $start_date = new DateTime($tanggal_awal);
        $end_date = new DateTime($tanggal_akhir);
        $interval = new DateInterval('P1D');
        $end_date->modify('+1 day');
        $date_range = new DatePeriod($start_date, $interval, $end_date);

        foreach ($date_range as $date) {
            $formatted_date = $date->format('Y-m-d');
            $full_date = $date->format('d M Y');

            $data_exists = false;
            foreach ($kelompok as $item) {
                $created_at = new DateTime($item->created_at);
                $created_at_formatted = $created_at->format('Y-m-d');
                if ($created_at_formatted === $formatted_date) {
                    $data_exists = true;
                    break;
                }
            }

            $status = $data_exists ? 'hadir' : 'alpax';
            $status_color = $data_exists ? 'bg-soft-success' : 'bg-soft-danger';
            $dates[] = [
                'full_date' => $full_date,
                'status' => $status,
                'status_color' => $status_color,
            ];

            if ($status === 'hadir') {
                $total_hadir++;
            } else {
                $total_alpa++;
            }
        }

        $total_days = $end_date->diff($start_date)->days;

        return view('Dosen.absen', compact('kelompok', 'dates', 'total_hadir', 'total_alpa', 'total_days'));

        // return redirect()->back()->with('success', 'Kegiatan Mahasiswa berhasil diperbarui.');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
