<?php

namespace App\Http\Controllers\Dosen;

use DateTime;
use DatePeriod;
use DateInterval;
use App\Models\Kelompok;
use App\Models\Proposal;
use App\Models\TabungTugas;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class KelompokMahasiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $allkelompok = Kelompok::where('ketua', '1')
        ->where('dosen', Auth::guard('dosen')->user()->nip)
        ->get();

        $nokelompokValues = $allkelompok->pluck('nokelompok')->toArray();
    $namakelompok = Kelompok::whereIn('nokelompok', $nokelompokValues)
        ->where('dosen', Auth::guard('dosen')->user()->nip)
        ->get()
        ->groupBy('nokelompok');


        // Mendapatkan nomor kelompok terakhir
        $lastKelompok = Kelompok::orderBy('id', 'desc')->first();

        // Inisialisasi nomor kelompok baru
        $nokelompok = 1;

        // Jika sudah ada kelompok sebelumnya, tambahkan satu ke nomor kelompok baru
        if ($lastKelompok) {
            $nokelompok = $lastKelompok->nokelompok + 1;
        }

        return view('Dosen.kelompok', compact('allkelompok','namakelompok'), ['nokelompok' => $nokelompok]);
    }

    public function kegiatan(Request $request, $id){
        $allkegiatan=TabungTugas::where('kelompoktugas', $id)->get();
        $kelompok = Kelompok::where('ketua', '1')
        ->where('dosen', Auth::guard('dosen')->user()->nip)
        ->get();
        return view('Dosen.kegiatan', compact('allkegiatan','kelompok'),['judul'=>'Halaman Absen']);
    }

    public function absen(Request $request, $id)
    {
         $tanggal_awal = '2024-07-24';
        $tanggal_akhir = '2024-09-07';

        $kelompok = TabungTugas::where('kelompoktugas', $id)->get();

        $dates = [];
        $total_hadir = 0;
        $total_alpa = 0;

        $start_date = new DateTime($tanggal_awal);
        $end_date = new DateTime($tanggal_akhir);
        $interval = new DateInterval('P1D');
        $end_date->modify('+1 day');
        $date_range = new DatePeriod($start_date, $interval, $end_date);

        foreach ($date_range as $date) {
            $formatted_date = $date->format('Y-m-d');
            $full_date = $date->format('d M Y');

            $data_exists = false;
            foreach ($kelompok as $item) {
                $created_at = new DateTime($item->created_at);
                $created_at_formatted = $created_at->format('Y-m-d');
                if ($created_at_formatted === $formatted_date) {
                    $data_exists = true;
                    break;
                }
            }

            $status = $data_exists ? 'hadir' : 'alpa atau belum melewati waktu yang ditentukan';
            $status_color = $data_exists ? 'bg-soft-success' : 'bg-soft-danger';
            $dates[] = [
                'full_date' => $full_date,
                'status' => $status,
                'status_color' => $status_color,
            ];

            if ($status === 'hadir') {
                $total_hadir++;
            } else {
                $total_alpa++;
            }
        }

        $total_days = $end_date->diff($start_date)->days;

        $kelompokabsen = Kelompok::where('ketua', '1')
        ->where('dosen', Auth::guard('dosen')->user()->nip)
        ->get();

        return view('Dosen.absen', compact('kelompok','kelompokabsen', 'dates', 'total_hadir', 'total_alpa', 'total_days'));

        // return redirect()->back()->with('success', 'Kegiatan Mahasiswa berhasil diperbarui.');
    }

    public function updateKegiatan(Request $request, $id)
    {
        $kegiatan = TabungTugas::findOrFail($id);
        $kegiatan->status = $request->input('status');
        $kegiatan->save();

        return redirect()->back()->with('success', 'Data mahasiswa berhasil disimpan.');

        // Redirect atau lakukan sesuatu yang sesuai dengan kebutuhan Anda
    }


    /**
     * Show the form for creating a new resource.
     */
    public function proposal(Request $request, $id)
    {
        //
        $allproposal=Proposal::where('kelompoktugas', $id)->get();
        $kelompok = Kelompok::where('ketua', '1')
        ->where('dosen', Auth::guard('dosen')->user()->nip)
        ->get();
        return view('Dosen.proposal', compact('allproposal','kelompok'),['judul'=>'Halaman Absen']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function updateProposal(Request $request, $id)
{
    $proposal = Proposal::findOrFail($id);
    $proposal->keterangan = $request->input('keterangan');
    $proposal->status = '2';
    $proposal->save();

    return redirect()->back()->with('success', 'Data mahasiswa berhasil disimpan.');

    // Redirect atau lakukan sesuatu yang sesuai dengan kebutuhan Anda
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
