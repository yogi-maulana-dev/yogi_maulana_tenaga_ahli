<?php

namespace App\Http\Controllers\Mahasiswa;

use App\Http\Controllers\Controller;
use App\Models\Falkultas;
use App\Models\Mahasiswa;
use App\Models\Prodi;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        return view('LoginUser.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function loginAction(Request $request)
    {
        // Validasi input
        $credentials = $request->validate(
            [
                'login_identifier' => [
                    'required',
                    'string',
                    function ($attribute, $value, $fail) {

                        if (! filter_var($value, FILTER_VALIDATE_EMAIL) && ! is_numeric($value)) {
                            $fail('Inputkan email atau NPM yang benar');
                        }
                    },
                ],
                'password' => 'required|string',
            ],
            [
                'login_identifier.required' => 'The email or NPM field is required.',
                'login_identifier.string' => 'Isi harus email atau NPM.',
                'password.required' => 'Password Harus Diisi.',
            ]
        );

        $field = filter_var($credentials['login_identifier'], FILTER_VALIDATE_EMAIL) ? 'email' : (is_numeric($credentials['login_identifier']) ? 'npm' : null);

        $status = 0;

        if ($field) {
            if (Auth::guard('web')->attempt([$field => $credentials['login_identifier'], 'password' => $credentials['password']])) {
                $request->session()->regenerate();
                $status = 1; // Login berhasil

                return redirect()
                    ->route('dashboard')
                    ->with(['aktif' => $status]);
            } else {
                return back()
                    ->withInput()
                    ->withErrors(['loginError' => 'Login gagal! Email, NPM, atau password salah cek kembali.']);
            }
        } else {
            return back()
                ->withInput()
                ->withErrors(['loginError' => 'Invalid input format! Please enter a valid email or NPM.']);
        }
    }

    public function logout()
    {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();

        return redirect(route('login'));
    }

    public function register(Request $request)
    {
        $prodix = Prodi::all();
        $fakultasx = Falkultas::all();

        return view('DaftarUser.index', compact('prodix', 'fakultasx'));

    }

    public function lupapassword(Request $request)
    {
        $prodix = Prodi::all();
        $fakultasx = Falkultas::all();

        return view('DaftarUser.lupa', compact('prodix', 'fakultasx'));

    }

    public function submitForgetPasswordForm(Request $request)
    {

        $request->validate([

            'email' => 'required|email|exists:users',

        ]);

        $token = Str::random(64);

        DB::table('password_resets')->insert([

            'email' => $request->email,

            'token' => $token,

            'created_at' => Carbon::now(),

        ]);

        Mail::send('email.forgetPassword', ['token' => $token], function ($message) use ($request) {

            $message->to($request->email);

            $message->subject('Reset Password');

        });

        return back()->with('message', 'We have e-mailed your password reset link!');

    }

    public function showResetPasswordForm($token)
    {

        return view('auth.forgetPasswordLink', ['token' => $token]);

    }

    public function submitResetPasswordForm(Request $request)
    {

        $request->validate([

            'email' => 'required|email|exists:users',

            'password' => 'required|string|min:6|confirmed',

            'password_confirmation' => 'required',

        ]);

        $updatePassword = DB::table('password_resets')
            ->where([

                'email' => $request->email,

                'token' => $request->token,

            ])
            ->first();

        if (! $updatePassword) {

            return back()->withInput()->with('error', 'Invalid token!');

        }

        $user = User::where('email', $request->email)
            ->update(['password' => Hash::make($request->password)]);

        DB::table('password_resets')->where(['email' => $request->email])->delete();

        return redirect('/login')->with('message', 'Your password has been changed!');

    }

    public function postregister(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'npm' => 'required|string|max:255|unique:mahasiswas,npm,'.$request->input('npm'),
                'namalengkap' => 'required|string|max:255',
                'email' => 'required|email|unique:mahasiswas,email',
                'jk' => 'required|string|max:255',
                'nohp' => 'required|string|max:255',
                'gambar' => 'required|image|max:5120', // Ubah sesuai kebutuhan Anda
                'gambarbayar' => 'required|image|max:5120', // Ubah sesuai kebutuhan Anda
                'alamat' => 'required|string|max:255',
                'fakultas' => 'required|string|max:255',
                'jurusan' => 'required|string|max:255',
                'sizebaju' => 'required|string|max:255',
                'kelas' => 'required|string',
            ],
            [
                'npm.required' => 'Nomor Pokok Mahasiswa wajib diisi',
                'kelas' => 'required|string|in:a,b', // validasi untuk gambar
                'npm.unique' => 'Nomor Pokok Mahasiswa sudah ada dalam database',
                'namalengkap.required' => 'Nama lengkap wajib diisi',
                'email.required' => 'Alamat email wajib diisi',
                'email.email' => 'Format email tidak valid',
                'email.unique' => 'Alamat email sudah digunakan',
                'jk.required' => 'Jenis kelamin wajib dipilih',
                'jk.in' => 'Pilih jenis kelamin yang sesuai',
                'fakultas.required' => 'Fakultas wajib dipilih',
                'fakultas.in' => 'Pilih fakultas yang sesuai',
                'jurusan.required' => 'Jurusan wajib dipilih',
                'jurusan.in' => 'Pilih Jurusan yang sesuai',
                'nohp.required' => 'Nomor handphone wajib diisi',
                'nohp.numeric' => 'Nomor handphone harus berupa angka',
                'alamat.required' => 'Alamat wajib diisi',
                'fakultas.required' => 'Fakultas wajib dipilih',
                'jurusan.required' => 'Jurusan wajib dipilih',
                'gambar.image' => 'File harus berupa Foto',
                'gambar.mimes' => 'Format Foto harus jpeg, png, jpg, atau gif',
                'gambar.max' => 'Ukuran foto maksimal 2MB',
                'gambarbayar.image' => 'File harus berupa Bukti Pembayaran',
                'gambarbayar.mimes' => 'Format Bukti Pembayaran harus jpeg, png, jpg, atau gif',
                'gambarbayar.max' => 'Ukuran Bukti Pembayaran maksimal 2MB',
            ]
        );

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $mahasiswa = new Mahasiswa();
        $mahasiswa->npm = $request->input('npm');
        $mahasiswa->namalengkap = $request->input('namalengkap');
        $mahasiswa->email = $request->input('email');
        $mahasiswa->jk = $request->input('jk');
        $mahasiswa->nohp = $request->input('nohp');
        $mahasiswa->alamat = $request->input('alamat');
        $mahasiswa->fakultas = $request->input('fakultas');
        $mahasiswa->jurusan = $request->input('jurusan');
        $mahasiswa->kelas = $request->input('kelas');
        $mahasiswa->tempat = $request->input('tempat');
        $mahasiswa->sizebaju = $request->input('sizebaju');
        $mahasiswa->password = Hash::make($request->input('npm'));

        // Upload gambar (jika ada)
        if ($request->hasFile('gambar')) {
            $gambar = $request->file('gambar');
            $npm = $request->input('npm'); // Mengambil NPM dari input form
            $nama_gambar = $npm.'_'.time().'.'.$gambar->getClientOriginalExtension(); // Menambahkan NPM ke nama gambar
            $lokasi = public_path('uploads/mahasiswa/foto');
            $gambar->move($lokasi, $nama_gambar);
            $mahasiswa->gambar = 'uploads/mahasiswa/foto/'.$nama_gambar;
        }

        if ($request->hasFile('gambarbayar')) {
            $gambarbayar = $request->file('gambarbayar');
            $npm = $request->input('npm'); // Mengambil NPM dari input form
            $nama_gambarbayar = $npm.'_'.time().'.'.$gambarbayar->getClientOriginalExtension(); // Menambahkan NPM ke nama gambarbayar
            $lokasi = public_path('uploads/mahasiswa/bukti');
            $gambarbayar->move($lokasi, $nama_gambarbayar);
            $mahasiswa->gambarbayar = 'uploads/mahasiswa/bukti/'.$nama_gambarbayar;
        }

        $mahasiswa->save();

        return redirect()->back()->with('success', 'Data mahasiswa berhasil disimpan.');

    }

    public function pengumuman()
    {
        return view('Pengumuman.index');
    }

    // public function pendaftaraan()
    // {
    //     $prodix = Prodi::all();
    //     $fakultasx = Falkultas::all();
    //     return view('DaftarUser.index', compact('prodix', 'fakultasx'));
    // }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        // Validasi data
        $request->validate(
            [

                'npm' => [
                    'required',
                    'string',
                    // 'numeric',
                    'max:14',

                    'unique:mahasiswas,npm',

                ],
                'namalengkap' => 'required|string|max:255',
                'email' => 'required|email|unique:mahasiswas,email',
                'jk' => 'required|string|max:255',
                'nohp' => 'required|string|max:255',
                'gambar' => 'required|image|mimes:jpg,jpeg,png|max:5204',
                'gambarbayar' => 'required|image|mimes:jpg,jpeg,png|max:5204',
                'alamat' => 'required|string|max:255',
                'tempat' => 'required|string|max:255',
                'tgllahir' => 'required|date',
                'fakultas' => 'required|string|max:255',
                'jurusan' => 'required|string|max:255',
                'sizebaju' => 'required|string|max:255',
                'password' => 'required|string|min:8|confirmed',
                'password_confirmation' => 'required|string|min:8',
                'kelas' => 'required|string|in:a,b',
                'customCheck1' => 'required|accepted', // Pastikan checkbox diperiksa
            ],
            [
                'npm.required' => 'Nomor Pokok Mahasiswa wajib diisi',
                'npm.unique' => 'Nomor Pokok Mahasiswa sudah ada',
                //   'npm.numeric' => 'Nomor Pokok Mahasiswa harus berupa angka',
                //   'npm.regex' => 'Nomor Pokok Mahasiswa harus dimulai atau diakhiri dengan satu huruf dan diikuti oleh angka',
                'namalengkap.required' => 'Nama lengkap wajib diisi',
                'email.required' => 'Alamat email wajib diisi',
                'email.email' => 'Format email tidak valid',
                'email.unique' => 'Alamat email sudah digunakan',
                'jk.required' => 'Jenis kelamin wajib dipilih',
                'jk.in' => 'Pilih jenis kelamin yang sesuai',
                'fakultas.required' => 'Fakultas wajib dipilih',
                'fakultas.in' => 'Pilih fakultas yang sesuai',
                'jurusan.required' => 'Jurusan wajib dipilih',
                'jurusan.in' => 'Pilih Jurusan yang sesuai',
                'nohp.required' => 'Nomor handphone wajib diisi',
                'nohp.numeric' => 'Nomor handphone harus berupa angka',
                'alamat.required' => 'Alamat wajib diisi',
                'tempat.max' => 'Tempat lahir tidak boleh melebihi 255 karakter',
                'tgllahir.required' => 'Tanggal lahir wajib diisi',
                'fakultas.required' => 'Fakultas wajib dipilih',
                'jurusan.required' => 'Jurusan wajib dipilih',
                'gambar.image' => 'File harus berupa Foto',
                'gambar.mimes' => 'Format Foto harus jpeg, png, jpg, atau gif',
                'gambar.max' => 'Ukuran foto maksimal 5MB',
                'gambarbayar.image' => 'File harus berupa Bukti Pembayaran',
                'gambarbayar.mimes' => 'Format Bukti Pembayaran harus jpeg, png, jpg, atau gif',
                'gambarbayar.max' => 'Ukuran Bukti Pembayaran maksimal 5MB',
                'kelas.required' => 'Kelas wajib dipilih',
                'kelas.in' => 'Pilih kelas yang tersedia',
                'customCheck1.required' => 'Anda harus menyetujui syarat dan ketentuan',
                'customCheck1.accepted' => 'Anda harus menyetujui syarat dan ketentuan',
            ]
        );

        $user = new Mahasiswa();
        $user->npm = $request->npm;
        $user->namalengkap = $request->namalengkap;
        $user->email = $request->email;
        $user->jk = $request->jk;
        $user->nohp = $request->nohp;
        $user->tgllahir = $request->tgllahir;
        $user->tempat = $request->tempat;

        if ($request->hasFile('gambar')) {
            $gambar = $request->file('gambar');
            $npm = $request->input('npm');
            $nama_gambar = $npm.'_'.time().'.'.$gambar->getClientOriginalExtension();
            $lokasi = public_path('uploads/mahasiswa/foto');
            $gambar->move($lokasi, $nama_gambar);
            $user->gambar = 'uploads/mahasiswa/foto/'.$nama_gambar;
        }
        if ($request->hasFile('gambarbayar')) {
            $gambarbayar = $request->file('gambarbayar');
            $npm = $request->input('npm');
            $nama_gambarbayar = $npm.'_'.time().'.'.$gambarbayar->getClientOriginalExtension();
            $lokasi = public_path('uploads/mahasiswa/bukti');
            $gambarbayar->move($lokasi, $nama_gambarbayar);
            $user->gambarbayar = 'uploads/mahasiswa/bukti/'.$nama_gambarbayar;
        }

        $user->alamat = $request->alamat;
        $user->fakultas = $request->fakultas;
        $user->jurusan = $request->jurusan;
        $user->sizebaju = $request->sizebaju;
        $user->password = bcrypt($request->password);
        $user->kelas = $request->kelas;
        $user->save();

        return redirect()->back()->with('success', 'Data berhasil disimpan!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
