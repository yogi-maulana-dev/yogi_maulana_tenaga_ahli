<?php

namespace App\Http\Controllers\Mahasiswa;

use App\Models\Setting;
use App\Models\Kelompok;
use App\Models\Proposal;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class ProposalController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Ambil data setting
        $allsetting = Setting::first();
    
        // Periksa apakah waktu saat ini melebihi waktu mulai yang ditentukan
        $waktu_mulai = $allsetting->waktu_mulai;
        $waktu_sekarang = now();
    
        if ($waktu_sekarang >= $waktu_mulai) {
            // Waktu sudah melewati waktu mulai, lanjutkan dengan proses pengambilan data proposal
    
            // Ambil data kelompok berdasarkan user saat ini
            $kelompok = Kelompok::where('npm', Auth::user()->npm)
                ->where('ketua', '1')
                ->first();
    
            if ($kelompok) {
                $proposal = Proposal::where('kelompoktugas', $kelompok->nokelompok)
                    ->latest()
                    ->take(1)
                    ->get();
    
                // Kirim data proposal ke view
                return view('Mahasiswa.proposal', compact('proposal'));
            } else {
                // Jika kelompok tidak ditemukan, kirim pesan kosong ke view
                return redirect()->route('peringatan')->with('error', 'Anda belum menjadi ketua kelompok, jika belum silakan hubungi admin.');
            }
        } else {
            // Waktu belum mencapai waktu mulai yang ditentukan, kirimkan pesan ke view
            return redirect()->route('peringatan')->with('warning', 'Waktu KKN belum mulai sesuai jadwal syarat untuk menampilkan proposal.');
        }
    }
    

    /**
     * Show the form for creating a new resource.
     */


     public function updateStatus($id)
     {
         try {
             // Update status menjadi 1
             Proposal::where('id', $id)->update(['status' => '2']);
     
             // Berhasil, kembalikan respons JSON
             return response()->json(['message' => 'Status berhasil diperbarui.']);
         } catch (\Exception $e) {
             // Jika terjadi kesalahan, kembalikan pesan error
             return response()->json(['message' => 'Terjadi kesalahan saat memperbarui status.'], 500);
         }
     }
     
     
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate(
            [
                'file' => 'required|file|mimes:pdf|max:5000',
                'keterangan' => 'required|string',
            ],
            [
                'file.required' => 'Wajib Ada file Kegiatan',
                'file.mimes' => 'Format file harus pdf',
                'file.max' => 'Ukuran files tidak boleh lebih dari 5 mb',
                'keterangan.required' => 'Keterangan harus diisi',
                'keterangan.string' => 'Keterangan harus berupa teks',
            ],
        );

        // Cari kelompok pengguna
        $kelompok = Kelompok::where('npm', Auth::user()->npm)
            ->where('ketua', '1')
            ->first();

        // Jika kelompok ditemukan
        if ($kelompok) {
            // Simpan files ke dalam folder
            $files = $request->file('file');
            // Mengatur zona waktu ke waktu Indonesia
            date_default_timezone_set('Asia/Jakarta');

            // Mendapatkan tanggal, bulan, dan tahun dalam format waktu Indonesia
            $tanggal_indo = date('d-m-Y');

            // Menggabungkan tanggal_indo dengan nokelompok dan waktu saat ini
            $nama_files = $tanggal_indo . '_' . $kelompok->nokelompok . '_' . time() . '.' . $files->getClientOriginalExtension();

            $lokasi = public_path('uploads/mahasiswa/proposal');
            $files->move($lokasi, $nama_files);

            // Buat dan simpan tugas ke database
            $proposal = new Proposal();
            $proposal->file = 'uploads/mahasiswa/proposal/' . $nama_files;
            $proposal->keterangan = $request->keterangan;
            $proposal->kelompoktugas = $kelompok->nokelompok;
            $proposal->created_at = Carbon::now('Asia/Jakarta');
 
            $proposal->save();

            return redirect()->route('proposal'); // Redirect ke route yang ditentukan
        } else {
            // Lakukan penanganan jika kelompok tidak ditemukan
            echo 'Kelompok tidak ditemukan.';
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
