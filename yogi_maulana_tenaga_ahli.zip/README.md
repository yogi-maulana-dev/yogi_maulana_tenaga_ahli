
# APLIKASI ARSIP

# NotesApp

kkn muhammadiah adalah Aplikasi untuk kkn mahasiswa

## Requitment
- **PHP**: PHP VERSI 8.1.
- **Mysql**: Tipe Mysql.
- **Laravel**: Framework Laravel 10.

## Cara Install Website
- **Pertama** masukan project ke d:/ cd kknlo/
- lalu buka terminal di dalam folder project ketikan composer i pada terminal lalu jalankan perintah php artisan serve
- cp .env.example .env.
- Update environment variables in .env
```dosini
APP_NAME="Name Your Project"
APP_URL=http://localhost:8080

DB_CONNECTION=mysql
DB_HOST=mysql
DB_PORT=3306
DB_DATABASE=nama_database
DB_USERNAME=root
DB_PASSWORD=

CACHE_DRIVER=redis
QUEUE_CONNECTION=redis
SESSION_DRIVER=redis

REDIS_HOST=redis
REDIS_PASSWORD=null
REDIS_PORT=6379

## Cara Install Website

- Masukan nama database yang ada pada project yaitu kknlo.sql, jalankan http://localhost/phpmyadmin/ lalu buat new atau baru dengan nama kknlo lalu pilih kknlo kemudian pilih import kknlo.sql



### Langkah-langkah untuk Menjalankan


1. **Langkah Pertama** Untuk url role mahasiswa link urlnya http://127.0.0.1:8000/, terdiri dari login dan daftar

2. **Langkah Kedua** Untuk url role mahasiswa link urlnya hhttp://127.0.0.1:8000/superadmin/login, untuk emadil : yogimaulana100@gmail.com dan password : asdf1234

3. **Langkah Ketiga** Setelah terdaftar mahasiswa harus dikonfirmasi dari superadmin di role menu yang ada di superadmin
   
Dengan instruksi di atas, pengguna baru dapat dengan mudah mengatur dan menjalankan aplikasi `KKN` di lingkungan lokal mereka.


